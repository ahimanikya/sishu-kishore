ଛୋଟ ପୁଟୁଳି · The Small Bundle
Concept and creative direction: Ahimanikya Satapathy

42 recording cues: 21 Odia and 21 English, for four fictional roles.
The eight recording sheets preserve the exact screenplay dialogue.
The bilingual cast brief and queue contain direction separately from spoken text.
Voice profiles are proposals, not selected or recorded voices.
No generation request, credits or account upgrade has been used for this film.

Save each recording under the exact queue name in recordings/or or recordings/en.
WAV and MP3 are accepted. Preserve the source takes and record the provider voice,
model, settings, plan and selection before building a voiced version.
The normal builder requires every recording; it never fills missing speech.
The sound study is an explicitly unvoiced 154-second pacing preview.
