ଛୋଟ ପୁଟୁଳି · The Small Bundle
ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା: ଅହିମାନିକ୍ୟ ଶତପଥୀ
Concept and creative direction: Ahimanikya Satapathy

index.html ଖୋଲି ଓଡ଼ିଆ, ଇଂରାଜୀ ବା ଉଭୟ ଭାଷାରେ ପଢ଼ନ୍ତୁ।
ଚାରିଟି ଚିତ୍ରପଟରେ ମୋଟ ଷୋହଳଟି ଦୃଶ୍ୟ। ପ୍ରଥମେ ଉପର ବାମ, ଉପର ଡାହାଣ,
ତା’ପରେ ତଳ ବାମ ଓ ତଳ ଡାହାଣ ଦୃଶ୍ୟ ପଢ଼ନ୍ତୁ। ସମୟ ୨:୩୪ ଆନୁମାନିକ।
ଏହା ପ୍ରଥମ ଖସଡ଼ା; କଣ୍ଠ ରେକର୍ଡ ଓ ଶେଷ ଚଳଚ୍ଚିତ୍ର ଅପେକ୍ଷିତ।

Open index.html in a browser. Choose Odia, English or both. Each pencil sheet
contains four shots: top left, top right, bottom left, bottom right.
Includes the two screenplays, bilingual source, timing list, all four pencil
sheets, established cast reference and the included font licence.
Planned duration: 2:34. First draft with silent still-frame playback.
Dialogue recording and animation are the next stages.
An original fictional episode set against Odisha's maritime heritage.
No specific historical date, port, route or authenticated costume is claimed.
