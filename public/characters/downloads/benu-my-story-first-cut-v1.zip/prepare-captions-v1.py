from pathlib import Path
import json
p=Path(__file__).parent
plan=json.loads((p/'timing-plan-v1.json').read_text())
cues=[{'start':c['start'],'end':c['end'],'or':c['speaker']['or']+': '+c['text']['or'],'en':c['speaker']['en']+': '+c['text']['en'],'type':'written-dialogue'} for c in plan['dialogueCues']]
sounds=[(0,.9,'[ପତ୍ରର ହାଲୁକା ଶବ୍ଦ]','[Leaves rustle softly]'),(8.4,10.7,'[ବାରଣ୍ଡାରେ ଶାନ୍ତ ପବନ]','[A quiet breeze on the verandah]'),(23,25.6,'[କପଡ଼ାର ହାଲୁକା ଘଷା]','[A soft rustle of clothing]'),(38,40.8,'[କପଡ଼ାର ହାଲୁକା ଘଷା]','[A soft rustle of clothing]'),(50.3,55.5,'[ପତ୍ରର ହାଲୁକା ଶବ୍ଦ]','[Leaves rustle softly]')]
cues+= [{'start':a,'end':b,'or':o,'en':e,'type':'sound-description'} for a,b,o,e in sounds]
cues.sort(key=lambda c:c['start'])
assert all(a['end']<=b['start'] for a,b in zip(cues,cues[1:]))
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d}.{ms%1000:03d}'
for lang in ['or','en']:
 text='WEBVTT\n\n'+''.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c[lang]}\n\n' for i,c in enumerate(cues))
 (p/f'captions-{lang}-v1.vtt').write_text(text.rstrip()+'\n')
(p/'caption-cues-v1.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2)+'\n')
print(f'{len(cues)} paired cues; six canonical dialogue lines.')
