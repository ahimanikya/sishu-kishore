from pathlib import Path
import json,wave
import numpy as np
p=Path(__file__).parent;sr=48000;duration=56;n=sr*duration;rng=np.random.default_rng(181018)
t=np.arange(n)/sr
white=rng.normal(0,1,n);leaves=np.convolve(white,np.ones(28)/28,mode='same')
leaves*=.012*(.7+.2*np.sin(2*np.pi*.17*t)+.1*np.sin(2*np.pi*.41*t))
audio=leaves.copy()
events=[(.3,.6,'cloth'),(3.5,.6,'cloth'),(11.8,.9,'cloth'),(22.3,1.1,'cloth'),(25,.6,'cloth'),(32.7,.7,'cloth'),(38.1,.6,'cloth'),(40.7,1.1,'cloth')]
for start,length,kind in events:
 count=int(length*sr);u=np.arange(count)/sr;env=np.sin(np.pi*np.arange(count)/max(1,count-1))**2
 noise=rng.normal(0,1,count);rustle=np.convolve(noise,np.ones(12)/12,mode='same')*.035*env
 if kind=='parcel':rustle+=.05*np.sin(2*np.pi*115*u)*np.exp(-u*18)
 if kind=='seat':rustle+=.012*np.sin(2*np.pi*(130*u+12*u*u))*env
 a=int(start*sr);audio[a:a+count]+=rustle
for start in []:
 count=int(.15*sr);u=np.arange(count)/sr;knock=.006*np.sin(2*np.pi*420*u)*np.exp(-u*45);a=int(start*sr);audio[a:a+count]+=knock
fade=np.minimum(1,np.minimum(t/.35,(duration-t)/.8));audio*=np.maximum(0,fade)
peak=float(np.max(np.abs(audio)));audio*=10**(-20/20)/peak
stereo=np.column_stack((audio,audio*.98));pcm=np.int16(np.clip(stereo,-1,1)*32767)
with wave.open(str(p/'sound-draft-v1.wav'),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes(pcm.tobytes())
review={'duration':duration,'sampleRate':sr,'channels':2,'peakDbFS':float(20*np.log10(np.max(np.abs(stereo)))),'rmsDbFS':float(20*np.log10(np.sqrt(np.mean(stereo**2)))),'clippedSamples':int(np.sum(np.abs(stereo)>=1)),'events':[{'time':a,'duration':b,'kind':k} for a,b,k in events],'provenance':'Original deterministic synthesized quiet leaf movement and clothing rustles. No human voices, breaths, laughter, music, field recordings or external samples.'}
(p/'sound-review-v1.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review,indent=2))
