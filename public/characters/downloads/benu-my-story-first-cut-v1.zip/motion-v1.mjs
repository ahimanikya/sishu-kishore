export const clamp=x=>Math.max(0,Math.min(1,x));
export const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
export const mix=(a,b,w)=>a.map((v,i)=>v+(b[i]-v)*w);
export function pulse(t,a,b,c,d){return ease((t-a)/(b-a))*(1-ease((t-c)/(d-c)))}
export function bPoint(p,t=0){const w=1-ease((p[1]-420)/180),breath=Math.sin(t*1.5)*.7;return[370+p[0]*.53+breath*w,625+(p[1]-600)*(p[1]<600?.48:.55)];}
export function mPoint(p,t=0){const w=1-ease((p[1]-420)/180),breath=Math.sin(t*1.25+.5)*.8;return[694+p[0]*.60+breath*w,630+(p[1]-600)*(p[1]<600?.62:.48)];}
export function stateAt(t){
 const cup=1-pulse(t,22,26,39.4,42),point=pulse(t,32.6,34.3,37.7,40),ask=pulse(t,11.8,13.1,22.2,25.8);
 const bShoulders=[[205,302],[411,307]].map(p=>bPoint(p,t)),mShoulders=[[310,330],[578,330]].map(p=>mPoint(p,t));
 const gesture=(t<11?Math.sin(t*.68)*5:t>42?Math.sin((t-42)*.55)*3:0)*cup;
 const bHands=[mix([539,635],[574+gesture,570-gesture*.3],cup),mix([627,635],[622+gesture,570-gesture*.3],cup)];
 const bElbows=[mix([461,570],[474,573],cup),mix([650,566],[650,560],cup)];
 if(point>0){const theta=1.892+(4.739-1.892)*point,radius=72.7+5.3*point;bElbows[1]=[650,566];bHands[1]=[650+radius*Math.cos(theta),566+radius*Math.sin(theta)];}
 const E=[830,557],ang=1.37+(5.35-1.37)*ask;
 const mHands=[[E[0]+100*Math.cos(ang),E[1]+100*Math.sin(ang)],[1005,645]],mElbows=[E,[1080,560]];
 const bs=t>32.5,ms=t>26;
 return{t,cup,point,ask,bShoulders,mShoulders,bHands,mHands,bElbows,mElbows,bSmile:bs,mSmile:ms};
}
const blinkTimes={b:[3.7,10.8,17.1,24.1,30.5,38.5,46.8,53.2],m:[6.2,11,19.8,25.7,33,40.4,48.5,54.7]};
export function faceAt(t,who){const blink=blinkTimes[who].some(a=>t>=a&&t<a+4/24);let pose=0;if(who==='b')pose=t>=32.5?2:t>=13?1:0;else pose=t>=26?2:t>=12&&t<=16?1:0;return{blink,pose:blink?3:pose};}
