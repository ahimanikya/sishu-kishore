import {createRequire} from 'node:module';
import {mkdir,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {stateAt,bPoint,mPoint,faceAt} from './motion-v1.mjs';
import {textureTriangle,skinArm,skinnedPoint} from './mesh-v1.mjs';
const require=createRequire(import.meta.url),{createCanvas,loadImage,GlobalFonts}=require(process.env.BATARE_CANVAS_MODULE||'@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url)),W=1536,H=1024,FPS=24,DURATION=56;
const [bg,b,m,props]=await Promise.all(['background-v1.png','benu-rig-v1.png','madhab-rig-v1.png','props-v1.png'].map(n=>loadImage(path.join(base,n))));
GlobalFonts.registerFromPath(path.join(base,'baloo-bhaina-2.ttf'),'Baloo Bhaina 2');
const canvas=createCanvas(W,H),main=canvas.getContext('2d'),layer=createCanvas(W,H),lc=layer.getContext('2d'),blend=createCanvas(W,H),bc=blend.getContext('2d');let ctx=main;
function part(img,rect,anchor,at,scale,angle=0){const[x,y,w,h]=rect;ctx.save();ctx.translate(...at);ctx.rotate(angle);ctx.scale(scale,scale);ctx.drawImage(img,x,y,w,h,x-anchor[0],y-anchor[1],w,h);ctx.restore();}
function mesh(img,rect,map,clip=null){const[x,y,w,h]=rect,nx=22,ny=30;for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){const a=[[x+w*i/nx,y+h*j/ny],[x+w*(i+1)/nx,y+h*j/ny],[x+w*(i+1)/nx,y+h*(j+1)/ny],[x+w*i/nx,y+h*(j+1)/ny]],d=a.map(map);textureTriangle(ctx,img,[a[0],a[1],a[2]],[d[0],d[1],d[2]],clip);textureTriangle(ctx,img,[a[0],a[2],a[3]],[d[0],d[2],d[3]],clip);}}
const B=[
 {rect:[620,650,350,320],a:[682,713],e:[712,846],b:[876,850],width:.53},
 {rect:[970,650,300,330],a:[1197,714],e:[1184,853],b:[1037,850],width:.53},
 {rect:[1290,630,245,340],a:[1360,740],e:[1402,883],b:[1470,748],width:.53}
];
const M=[
 {rect:[650,625,295,375],a:[755,690],e:[730,825],b:[858,917],width:.60},
 {rect:[975,625,300,380],a:[1160,690],e:[1180,835],b:[1040,935],width:.60},
 {rect:[1270,645,265,330],a:[1355,716],e:[1343,888],b:[1465,795],width:.60}
];
const HB=[
 {rect:[625,10,350,325],anchor:[810,303]},
 {rect:[1010,10,330,325],anchor:[1200,303]},
 {rect:[625,335,350,320],anchor:[810,625]},
 {rect:[1010,335,330,320],anchor:[1200,625]}
],HM=[
 {rect:[790,15,285,310],anchor:[942,287]},
 {rect:[1090,15,285,310],anchor:[1234,287]},
 {rect:[790,325,285,295],anchor:[942,583]},
 {rect:[1090,325,285,295],anchor:[1234,583]}
];
// The torso's duplicate empty sleeves are excluded when assembling its separate arm layers.
const bodyClipB=[[238,202],[357,202],[405,278],[414,444],[435,515],[595,540],[600,1004],[80,1004],[80,550],[171,490],[188,444],[216,381],[214,280]];
function arm(img,def,A,E,H){skinArm(ctx,img,def,A,E,H);return{shoulder:A,elbow:E,hand:H,renderedHand:skinnedPoint(def.b,def,A,E,H),upperLength:Math.hypot(E[0]-A[0],E[1]-A[1]),foreLength:Math.hypot(H[0]-E[0],H[1]-E[1])};}
function armBlend(img,defs,A,E,hand,w){
 const selected=w<.5?0:1;
 const drawn=arm(img,defs[selected],A,E,hand);
 return{w,selected,parts:defs.map(g=>({renderedHand:skinnedPoint(g.b,g,A,E,hand)})),...drawn};
}

function draw(t){
 const s=stateAt(t),bf=faceAt(t,'b'),mf=faceAt(t,'m');ctx=main;ctx.clearRect(0,0,W,H);ctx.drawImage(bg,0,0,W,H);
 part(props,[0,670,690,760],[355,1382],[1185,649],.25);
 part(props,[730,30,294,1450],[765,1452],[1290,767],.30);
 const feetB=[[245,950],[495,934]].map(p=>bPoint(p,t)),feetM=[[180,946],[472,975]].map(p=>mPoint(p,t));
 [...feetB,...feetM].forEach(p=>{ctx.fillStyle='rgba(55,40,25,.11)';ctx.beginPath();ctx.ellipse(p[0],p[1]+2,33,7,0,0,Math.PI*2);ctx.fill();});
 const hb=HB[bf.pose],hm=HM[mf.pose],bAngle=t>14&&t<22?-.025:Math.sin(t*.62)*.008,mAngle=s.ask*.028;
 part(b,hb.rect,hb.anchor,bPoint([318,245],t),.50,bAngle);
 mesh(b,[80,200,530,804],p=>bPoint(p,t),bodyClipB);
 mesh(m,[65,225,600,775],p=>mPoint(p,t));
 part(m,hm.rect,hm.anchor,mPoint([431,255],t),.62,mAngle);
 const mFar=arm(m,M[1],s.mShoulders[1],s.mElbows[1],s.mHands[1]);
 const mNear=armBlend(m,[M[0],M[2]],s.mShoulders[0],s.mElbows[0],s.mHands[0],s.ask);
 const bFar=armBlend(b,[B[1],B[2]],s.bShoulders[1],s.bElbows[1],s.bHands[1],s.point);
 const bNear=arm(b,B[0],s.bShoulders[0],s.bElbows[0],s.bHands[0]);
 ctx.fillStyle='rgba(250,246,232,.97)';ctx.fillRect(0,925,W,99);ctx.fillStyle='#273c35';ctx.font='30px "Baloo Bhaina 2"';ctx.fillText('ଆଗେ ମୋ ଗପ · ଚଳଚ୍ଚିତ୍ର ଖସଡ଼ା',42,964);ctx.font='22px sans-serif';ctx.fillText('My Story First · Animation draft',42,997);ctx.textAlign='right';ctx.font='21px sans-serif';ctx.fillText('Concept and creative direction: Ahimanikya Satapathy',1494,966);ctx.font='22px "Baloo Bhaina 2"';ctx.fillText('ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା: Ahimanikya Satapathy',1494,998);ctx.textAlign='left';
 return{t,feetB,feetM,arms:{bNear,bFar,mNear,mFar},faces:{benu:bf,madhab:mf},gesture:{cup:s.cup,point:s.point,ask:s.ask},props:{bag:[1185,649],umbrella:[1290,767]}};
}
await mkdir(path.join(base,'proof'),{recursive:true});
for(const t of [0,3,7,11.8,12.4,13.2,15,20,23.5,26,30,33.4,35,38.6,40,43,49,55.5]){draw(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'));}
if(process.argv.includes('--proof-only')){console.log('Proof frames saved.');process.exit(0);}
const ff=spawn(process.env.BATARE_FFMPEG||'ffmpeg',['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-i',path.join(base,'sound-draft-v1.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(DURATION),path.join(base,'my-story-first-cut-v1.mp4')],{stdio:['pipe','inherit','inherit']});
const done=once(ff,'close'),audit=[];
for(let i=0;i<FPS*DURATION;i++){audit.push(draw(i/FPS));const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain');if(i%240===0)console.log(`${i}/${FPS*DURATION}`);}
ff.stdin.end();const[code]=await done;if(code)throw Error('Encode failed '+code);await writeFile(path.join(base,'motion-audit-v1.json'),JSON.stringify({frames:audit,notes:'First animation draft. Provisional written dialogue, no recorded acting. Drawing deformation, not anatomical simulation.'},null,2)+'\n');console.log(`Rendered ${FPS*DURATION}frames/${DURATION}s.`);
