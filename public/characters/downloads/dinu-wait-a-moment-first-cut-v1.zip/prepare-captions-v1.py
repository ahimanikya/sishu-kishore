from pathlib import Path
import json
p=Path(__file__).parent;cues=json.loads((p/'caption-cues-v1.json').read_text())
def stamp(v):
 ms=round(v*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}.{ms%1000:03}'
for lang in ['or','en']:
 blocks=['WEBVTT']
 for i,c in enumerate(cues,1):
  text=c['text'][lang]
  if c.get('speaker'):text=c['speaker'][lang]+': '+text
  blocks.append(f'{i}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{text}')
 (p/f'captions-{lang}-v1.vtt').write_text('\n\n'.join(blocks)+'\n')
print('Nine paired cues saved, including four unchanged dialogue lines.')
