from pathlib import Path
import json,wave
import numpy as np
p=Path(__file__).parent;sr=48000;duration=54;n=sr*duration;rng=np.random.default_rng(181026);t=np.arange(n)/sr
# Original synthesized quiet air movement, paper and cloth; no external recordings.
audio=np.convolve(rng.normal(0,1,n),np.ones(40)/40,mode='same')*.004
events=[(.4,.7,'paper'),(1.5,.6,'paper'),(3.2,.5,'cloth'),(20.8,1.2,'cloth'),(27.2,.8,'paper'),(30.3,.7,'paper'),(31.5,.7,'crease'),(33.5,.5,'cloth'),(38.4,.3,'pencil-lift'),(43,.16,'pencil-tap')]
for start,length,kind in events:
 count=int(length*sr);u=np.arange(count)/sr;env=np.sin(np.pi*np.arange(count)/max(1,count-1))**2
 if kind.startswith('pencil'):sound=.035*np.sin(2*np.pi*650*u)*np.exp(-u*38)
 else:
  kernel=6 if kind in ['paper','crease'] else 16
  sound=np.convolve(rng.normal(0,1,count),np.ones(kernel)/kernel,mode='same')*.03*env
  if kind=='crease':sound+=.008*np.sin(2*np.pi*1200*u)*env
 a=int(start*sr);audio[a:a+count]+=sound
fade=np.maximum(0,np.minimum(1,np.minimum(t/.35,(duration-t)/.8)));audio*=fade;audio*=10**(-20/20)/np.max(np.abs(audio));stereo=np.column_stack((audio,audio*.98));pcm=np.int16(np.clip(stereo,-1,1)*32767)
with wave.open(str(p/'sound-draft-v1.wav'),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes(pcm.tobytes())
review={'duration':duration,'sampleRate':sr,'channels':2,'peakDbFS':float(20*np.log10(np.max(np.abs(stereo)))),'rmsDbFS':float(20*np.log10(np.sqrt(np.mean(stereo**2)))),'clippedSamples':int(np.sum(np.abs(stereo)>=1)),'events':[{'time':a,'duration':b,'kind':k} for a,b,k in events],'provenance':'Original deterministic synthesized paper, cloth, pencil contacts and quiet air. No human voices, breaths, laughter, music, field recordings or external samples.'}
(p/'sound-review-v1.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review,indent=2))
