import {createRequire} from 'node:module';
import {mkdir,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {stateAt,faceAt,project,ease} from './motion-v1.mjs';
import {textureTriangle,skinArm,skinnedPoint} from './mesh-v1.mjs';
const require=createRequire(import.meta.url),{createCanvas,loadImage,GlobalFonts}=require(process.env.MAKERS_CANVAS_MODULE||'@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url)),W=1536,H=1024,FPS=24,DURATION=54;
const [bg,tara,dinu,kanu,props,dinuConnected,taraHeads]=await Promise.all(['background-v1.png','tara-rig-v1.png','dinu-rig-v1.png','kanu-rig-v1.png','props-v1.png','dinu-connected-v2.png','tara-heads-v2.png'].map(n=>loadImage(path.join(base,n))));
GlobalFonts.registerFromPath(path.join(base,'baloo-bhaina-2.ttf'),'Baloo Bhaina 2');
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d');
function part(img,rect,anchor,at,scale,angle=0,clip=null){const[x,y,w,h]=rect;ctx.save();ctx.translate(...at);ctx.rotate(angle);ctx.scale(scale,scale);if(clip){ctx.beginPath();clip.forEach((p,i)=>i?ctx.lineTo(p[0]-anchor[0],p[1]-anchor[1]):ctx.moveTo(p[0]-anchor[0],p[1]-anchor[1]));ctx.closePath();ctx.clip();}ctx.drawImage(img,x,y,w,h,x-anchor[0],y-anchor[1],w,h);ctx.restore();}
const T=[{rect:[600,675,300,285],a:[700,701],e:[660,845],b:[875,900],width:.60},{rect:[1220,690,310,285],a:[1280,717],e:[1290,850],b:[1450,911],width:.60}];
const D=[{rect:[550,650,380,365],a:[865,671],e:[755,820],b:[652,952],width:.60},{rect:[965,650,250,355],a:[1027,677],e:[1141,835],b:[1090,945],width:.60},{rect:[1250,650,280,355],a:[1325,680],e:[1445,841],b:[1403,945],width:.60}];
const DC={rect:[55,160,355,730],a:[300,260],e:[180,540],b:[220,800],width:.44,clip:[[230,175],[368,195],[393,300],[320,560],[300,705],[350,790],[350,855],[100,880],[65,490],[125,365]]};
const K=[{rect:[80,710,550,270],a:[545,724],e:[473,879],b:[182,913],width:.59},{rect:[630,690,410,280],a:[945,709],e:[983,898],b:[670,855],width:.59}];
const HT=[{rect:[150,10,560,480],anchor:[410,445]},{rect:[810,10,560,480],anchor:[1100,452]},{rect:[150,500,560,480],anchor:[415,930]},{rect:[830,500,560,480],anchor:[1115,935]}];
const HD=[{rect:[690,0,325,330],anchor:[842,300]},{rect:[1050,0,325,330],anchor:[1204,300]},{rect:[690,330,325,320],anchor:[842,620]},{rect:[1050,330,325,320],anchor:[1204,620]}];
const HK=[{rect:[550,5,355,345],anchor:[787,320]},{rect:[930,5,365,345],anchor:[1105,320]},{rect:[600,365,325,325],anchor:[810,657]},{rect:[945,365,350,325],anchor:[1125,650]}];
const bodyT=[[280,257],[375,257],[425,310],[430,550],[585,680],[585,925],[45,925],[45,550],[190,505],[220,380],[245,293]];
function arm(img,g,A,E,H){skinArm(ctx,img,g,A,E,H);return{shoulder:A,elbow:E,hand:H,renderedHand:skinnedPoint(g.b,g,A,E,H)};}
function poly(points,fill,stroke='#665442',width=2){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke();}}
function paperFace(points,shade=0){const src=[[120,120],[1120,120],[1120,920],[120,920]];textureTriangle(ctx,props,[src[0],src[1],src[2]],[points[0],points[1],points[2]]);textureTriangle(ctx,props,[src[0],src[2],src[3]],[points[0],points[2],points[3]]);poly(points,shade?`rgba(80,60,30,${shade})`:null);}
const pp=points=>points.map(project);
function tray(s){
 ctx.fillStyle='rgba(53,35,22,.13)';ctx.beginPath();ctx.ellipse(820,755,178,49,.15,0,Math.PI*2);ctx.fill();
 paperFace(pp([[0,180,0],[280,180,0],[280,180,55],[0,180,55]]),.06);
 paperFace(pp([[0,0,0],[280,0,0],[280,180,0],[0,180,0]]));
 paperFace(pp([[280,0,0],[280,180,0],[280,180,55],[280,0,55]]),.10);
 paperFace(pp([[0,0,0],[0,180,0],[0,180,55],[0,0,55]]),.03);
 paperFace(pp([[0,0,0],[280,0,0],[280,0,55],[0,0,55]]),.09);
 // Corner tabs already secured before this scene; the front-left tab remains active.
 for(const p of [[[252,0,55],[280,0,55],[280,0,23]],[[280,152,55],[280,180,55],[280,180,23]],[[0,150,55],[0,180,55],[0,180,24]]])poly(pp(p),null,'#a49175',1.3);
 paperFace(s.paper.tab,.025);
 if(s.paper.insert>0){const x=34-10*s.paper.insert;paperFace(pp([[x,0,22],[37,0,22],[37,0,46],[x,0,46]]),.09);}
 ctx.beginPath();ctx.moveTo(...s.paper.slot[0]);ctx.lineTo(...s.paper.slot[1]);ctx.strokeStyle='#675845';ctx.lineWidth=2.2;ctx.stroke();
}
function draw(t){const s=stateAt(t),ft=faceAt(t,'tara'),fd=faceAt(t,'dinu'),fk=faceAt(t,'kanu');ctx.clearRect(0,0,W,H);const zoom=1+.65*ease((t-24)/1.2)*(1-ease((t-34)/1.2));ctx.save();ctx.translate(W/2,500);ctx.scale(zoom,zoom);ctx.translate(-W/2,-(500+(zoom-1)*230));ctx.drawImage(bg,0,0);
 // Torso and behind-back arm layers are occluded by the fixed back edge of the table.
 ctx.save();ctx.beginPath();ctx.rect(0,0,W,615);ctx.clip();
 let dr;
 if(s.dinuArmsBehind)dr=arm(dinuConnected,DC,s.da[0],s.de[0],s.dh[0]);
 part(dinuConnected,[280,80,700,1460],[560,140],[790,310],.44,0,[[230,175],[370,135],[465,80],[670,90],[820,215],[970,420],[960,650],[850,780],[970,1536],[280,1536],[320,1000],[355,880],[355,780],[325,710],[320,615],[350,455],[350,340],[300,270]]);
 const dhead=HD[fd.pose];part(dinu,dhead.rect,dhead.anchor,[790,310],.64,Math.sin(t*.5)*.007);
 if(!s.dinuArmsBehind)dr=arm(dinuConnected,DC,s.da[0],s.de[0],s.dh[0]);
 arm(tara,T[0],s.ta[0],s.te[0],s.th[0]);arm(tara,T[1],s.ta[1],s.te[1],s.th[1]);
 const thead=HT[ft.pose];part(taraHeads,thead.rect,thead.anchor,[520,445],.43,t>=12&&t<23?-.018:0);
 part(tara,[40,250,550,680],[330,280],[520,445],.60);
 part(kanu,[125,200,455,510],[350,260],[1130,430],.59);
 const khead=HK[fk.pose];part(kanu,khead.rect,khead.anchor,[1130,440],.63);
 ctx.restore();
 if(!s.dinuArmsBehind){ctx.save();ctx.beginPath();ctx.rect(0,615,W,H-615);ctx.clip();dr=arm(dinuConnected,DC,s.da[0],s.de[0],s.dh[0]);ctx.restore();}
 tray(s);
 ctx.save();ctx.beginPath();ctx.rect(0,500,W,H-500);ctx.clip();const tf=arm(tara,T[1],s.ta[1],s.te[1],s.th[1]);ctx.restore();
 const kf=arm(kanu,K[0],s.ka[0],s.ke[0],s.kh[0]);
 // Draw the single pencil once; the grasping fingers then overlap it.
 part(props,[1275,110,85,830],[1320,600],s.pencil,.17,s.pencilAngle);
 ctx.save();ctx.beginPath();ctx.rect(0,500,W,H-500);ctx.clip();const tn=arm(tara,T[0],s.ta[0],s.te[0],s.th[0]);ctx.restore();const kn=arm(kanu,K[1],s.ka[1],s.ke[1],s.kh[1]);
 ctx.restore();ctx.fillStyle='rgba(250,246,232,.97)';ctx.fillRect(0,925,W,99);ctx.fillStyle='#273c35';ctx.font='30px "Baloo Bhaina 2"';ctx.fillText('ଟିକେ ରୁହ, ମାମୁ · ଚଳଚ୍ଚିତ୍ର ଖସଡ଼ା',42,964);ctx.font='22px sans-serif';ctx.fillText('Wait a Moment, Mamu · Animation draft',42,997);ctx.textAlign='right';ctx.font='21px sans-serif';ctx.fillText('Concept and creative direction: Ahimanikya Satapathy',1494,966);ctx.font='22px "Baloo Bhaina 2"';ctx.fillText('ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା: Ahimanikya Satapathy',1494,998);ctx.textAlign='left';
 return{t,arms:{taraNear:tn,taraFar:tf,dinuReach:dr,kanuNear:kn,kanuFar:kf},faces:{tara:ft,dinu:fd,kanu:fk},paper:s.paper,handRelease:s.release,pencil:{at:s.pencil,angle:s.pencilAngle,held:s.pencilHeld,instances:1},dinuArmsBehind:s.dinuArmsBehind,tableBackY:615,cameraZoom:zoom};
}
await mkdir(path.join(base,'proof'),{recursive:true});
for(const t of [0,4,7,15,21,23.5,24,28,30,31.5,32.5,34.5,36,38.4,40.5,43,46,53.5]){draw(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'));}
if(process.argv.includes('--proof-only')){console.log('Proof frames saved.');process.exit(0);}
const ff=spawn(process.env.MAKERS_FFMPEG||'ffmpeg',['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-i',path.join(base,'sound-draft-v1.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(DURATION),path.join(base,'wait-a-moment-first-cut-v1.mp4')],{stdio:['pipe','inherit','inherit']});
const done=once(ff,'close'),audit=[];
for(let i=0;i<FPS*DURATION;i++){audit.push(draw(i/FPS));const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain');if(i%240===0)console.log(`${i}/${FPS*DURATION}`);}
ff.stdin.end();const[code]=await done;if(code)throw Error('Encode failed '+code);await writeFile(path.join(base,'motion-audit-v1.json'),JSON.stringify({frames:audit,notes:'First animation draft. No recorded voices. Paper texture mapped onto native folding geometry; illustrated arm deformation, not anatomical simulation.'},null,2)+'\n');console.log(`Rendered ${FPS*DURATION} frames/${DURATION}s.`);
