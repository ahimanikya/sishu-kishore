export const clamp=x=>Math.max(0,Math.min(1,x));
export const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
export const mix=(a,b,w)=>a.map((v,i)=>v+(b[i]-v)*w);
const move=(t,a,b,A,B)=>mix(A,B,ease((t-a)/(b-a)));
export const project=([x,y,z])=>[640+.85*x+.65*y,735+.24*x-.44*y-z];
export function paperAt(t){
 const turn=ease((t-27)/(30.5-27)),insert=ease((t-30.5)/(32.5-30.5)),angle=(1-turn)*1.05;
 const tab=(x,z)=>project([x*Math.cos(angle),-x*Math.sin(angle),z]);
 return{turn,insert,angle,contact:tab(34-10*insert,33),tab:[tab(0,24),tab(34,24),tab(34,44),tab(0,44)],slot:[project([24,0,24]),project([24,0,44])],locked:t>=32.5};
}
export function stateAt(t){
 const paper=paperAt(t),release=ease((t-33.2)/(35.8-33.2)),reach=ease((t-2.8)/3.6),withdraw=ease((t-20.6)/3.9);
 const ta=[[454,475],[577,478]],te=[[472,630],[625,585]],th=[mix(paper.contact,[567,658],release),mix(project([0,145,54]),[650,630],release)];
 const da=[[675.6,362.8],[904,348]],de=[mix([641,482],[634,470],withdraw),[953,476]],dh=[mix(mix([660,570],[625,650],reach),[785,540],withdraw),[838,553]];
 const ka=[[1041,454],[1206,454]],ke=[[1102,602],[1185,645]],kh=[mix(project([275,160,50]),[1015,674],release),mix(project([280,80,50]),[1100,710],release)];
 if(t>=36.4)kh[1]=move(t,36.4,38.4,[1100,710],[1120,775]);
 let pencil=[1120,775],pencilAngle=-1.1,held=false;
 if(t>=38.4&&t<43){const q=ease((t-38.4)/4.6);pencil=mix([1120,775],[850,708],q);pencil[1]-=Math.sin(Math.PI*q)*75;held=true;kh[1]=pencil;}
 else if(t>=43){pencil=[850,708];kh[1]=move(t,43,45,[850,708],[1080,710]);}
 if(t>=38.4&&t<43)ke[1]=mix([1185,645],[1095,638],ease((t-38.4)/4.6));
 else if(t>=43)ke[1]=move(t,43,45,[1095,638],[1185,645]);
 return{t,paper,release,reach,withdraw,ta,te,th,da,de,dh,ka,ke,kh,pencil,pencilAngle,pencilHeld:held,dinuArmsBehind:t>=23.6};
}
const blinks={tara:[3.8,10.8,18.5,24.4,34.4,41.6,49.6],dinu:[6.9,12.8,21,29.9,37.6,45.7,51.5],kanu:[2.8,9.8,17.3,25.1,32.9,40.3,48.3]};
export function faceAt(t,who){let pose=0;if(who==='tara')pose=t>=35?2:t>=12&&t<23?1:0;else if(who==='dinu')pose=t>=43?2:t>=12?1:0;else pose=t>=43?2:t>=14&&t<22?1:0;const blink=blinks[who].some(a=>t>=a&&t<a+4/24);return{pose:blink?3:pose,blink};}
