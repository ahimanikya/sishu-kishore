from pathlib import Path
import json
b=Path(__file__).resolve().parent;prep=json.loads((b/'timing-plan-v1.json').read_text())
cues=[{'start':c['start'],'end':c['end'],'text':{l:c['speaker'][l]+': '+c['text'][l] for l in ['or','en']}} for c in prep['dialogueCues']]
for a,z,or_,en in [(0,.7,'[ହାଲୁକା ପବନ]','[Soft breeze]'),(5.3,11.2,'[କୁହୁ ଡାକର ଖସଡ଼ା]','[Two-note call sketch]'),(18.8,19.8,'[ପତ୍ରରେ ଏକ ଠୋପା: ଟପ୍]','[A drop taps the leaf]'),(24.4,25.2,'[ଆଉ ଏକ ଠୋପା: ଟପ୍]','[Another drop taps]'),(32.3,33.3,'[ଟପ୍; ପତ୍ର ହଲେ]','[Tap; the leaf dips]'),(42,46.7,'[ଦୁଇଟି ଠୋପା; ହାଲୁକା ପବନ]','[Two drops; a light breeze]')]:cues.append({'start':a,'end':z,'text':{'or':or_,'en':en}})
cues.sort(key=lambda c:c['start'])
def stamp(s):return f'00:{int(s)//60:02}:{int(s)%60:02}.{round((s%1)*1000):03}'
for l in ['or','en']:
 text='WEBVTT\n\nNOTE Written dialogue uses provisional timing; no recorded speech.\n\n'
 text+='\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"][l]}' for i,c in enumerate(cues))+'\n'
 (b/f'captions-{l}-v1.vtt').write_text(text)
(b/'caption-cues-v1.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2)+'\n');print(len(cues),'cues per language')
