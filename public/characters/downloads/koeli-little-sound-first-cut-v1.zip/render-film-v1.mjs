import {createRequire} from 'node:module';
import {writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {stateAt,bodyPoint,leafPoint,dropPoint,impacts} from './motion-v1.mjs';
const require=createRequire(import.meta.url),{createCanvas,loadImage,GlobalFonts}=require(process.env.KOELI_CANVAS_MODULE||'@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url));
const [bg,rig,heads]=await Promise.all(['background-v1.png','rig-v2.png','head-atlas-v1.png'].map(f=>loadImage(path.join(base,f))));
GlobalFonts.registerFromPath(path.join(base,'baloo-bhaina-2.ttf'),'Baloo Bhaina 2');
const W=1536,H=1024,FPS=24,DURATION=48,canvas=createCanvas(W,H),ctx=canvas.getContext('2d');
function piece(img,rect,anchor,at,scale,angle=0){ctx.save();ctx.translate(...at);ctx.rotate(angle);ctx.scale(scale,scale);ctx.drawImage(img,...rect,rect[0]-anchor[0],rect[1]-anchor[1],rect[2],rect[3]);ctx.restore();}
function triangle(img,src,dst){
 const [a,b,c]=src,[A,B,C]=dst,x1=b[0]-a[0],y1=b[1]-a[1],x2=c[0]-a[0],y2=c[1]-a[1],den=x1*y2-x2*y1;
 const xx=((B[0]-A[0])*y2-(C[0]-A[0])*y1)/den,xy=(-(B[0]-A[0])*x2+(C[0]-A[0])*x1)/den,yx=((B[1]-A[1])*y2-(C[1]-A[1])*y1)/den,yy=(-(B[1]-A[1])*x2+(C[1]-A[1])*x1)/den;
 const mid=[(A[0]+B[0]+C[0])/3,(A[1]+B[1]+C[1])/3],expand=p=>{const d=Math.max(.001,Math.hypot(p[0]-mid[0],p[1]-mid[1]));return p.map((v,i)=>v+(v-mid[i])*.7/d)};
 ctx.save();ctx.beginPath();ctx.moveTo(...expand(A));ctx.lineTo(...expand(B));ctx.lineTo(...expand(C));ctx.closePath();ctx.clip();ctx.transform(xx,yx,xy,yy,A[0]-xx*a[0]-xy*a[1],A[1]-yx*a[0]-yy*a[1]);ctx.drawImage(img,0,0);ctx.restore();
}
function body(s){
 // Keep the lower body, feet and tail as an exact unwarped drawing.
 ctx.drawImage(rig,0,400,710,410,30,560,710,410);
 const nx=24,ny=16;
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
  const src=[[i*710/nx,j*400/ny],[(i+1)*710/nx,j*400/ny],[(i+1)*710/nx,(j+1)*400/ny],[i*710/nx,(j+1)*400/ny]],dst=src.map(p=>bodyPoint(p,s));
  triangle(rig,[src[0],src[1],src[2]],[dst[0],dst[1],dst[2]]);triangle(rig,[src[0],src[2],src[3]],[dst[0],dst[2],dst[3]]);
 }
}
const faceParts=[{rect:[180,40,570,460],anchor:[500,350]},{rect:[850,40,570,460],anchor:[1170,350]},{rect:[180,530,570,460],anchor:[500,840]},{rect:[850,530,570,460],anchor:[1170,840]}];
function draw(t){
 const s=stateAt(t);ctx.clearRect(0,0,W,H);ctx.drawImage(bg,0,0,W,H);
 const neck=bodyPoint([585,140],s),face=s.blink?3:s.opening>.72?2:s.opening>.12?1:0,g=faceParts[face];
 piece(heads,g.rect,g.anchor,neck,.54,s.headAngle);body(s);
 piece(rig,[0,810,720,444],[620,900],[1440,575],.8,s.leafAngle);
 const drops=[];
 for(const at of impacts){
  if(t>=at-.72&&t<at){const pos=dropPoint(at,t);piece(rig,[900,810,350,444],[1008,1077],pos,.12);drops.push({impact:at,position:pos});}
  const d=t-at;if(d>=0&&d<.55){ctx.save();ctx.globalAlpha=(1-d/.55)*.65;ctx.strokeStyle='#e5eff0';ctx.lineWidth=2;ctx.beginPath();const hit=leafPoint([195,968.75],s);ctx.ellipse(hit[0],hit[1],6+d*48,2+d*9,-.19+s.leafAngle,0,Math.PI*2);ctx.stroke();ctx.restore();}
 }
 ctx.save();ctx.fillStyle='rgba(250,246,232,.95)';ctx.fillRect(0,925,W,99);ctx.fillStyle='#273c35';ctx.font='30px "Baloo Bhaina 2"';ctx.fillText('ସେଇ ଛୋଟ ଶବ୍ଦ · ଚଳଚ୍ଚିତ୍ର ଖସଡ଼ା',42,964);ctx.font='22px sans-serif';ctx.fillText('That Little Sound · Animation draft',42,997);ctx.textAlign='right';ctx.font='21px sans-serif';ctx.fillText('Concept and creative direction: Ahimanikya Satapathy',1494,966);ctx.font='22px "Baloo Bhaina 2"';ctx.fillText('ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା: Ahimanikya Satapathy',1494,998);ctx.restore();
 return {t,phase:s.phase,opening:s.opening,blink:s.blink,face,headAt:neck,headAngle:s.headAngle,lean:s.lean,feet:[[490,668],[646,601]],leafAttachment:leafPoint([620,900],s),leafImpact:leafPoint([195,968.75],s),leafAngle:s.leafAngle,drops};
}
await mkdir(path.join(base,'proof'),{recursive:true});
for(const t of [0,1.3,4.17,4.3,6.2,12,15,19.1,24,24.58,24.8,27,31.45,35,38,41.15,42.3,46.1,47.8]){draw(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'));}
if(process.argv.includes('--proof-only')){console.log('Nineteen proof frames saved.');process.exit(0);}
const ff=spawn(process.env.KOELI_FFMPEG||'ffmpeg',['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-i',path.join(base,'sound-draft-v1.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(DURATION),path.join(base,'that-little-sound-first-cut-v1.mp4')],{stdio:['pipe','inherit','inherit']});
const completion=once(ff,'close'),frames=[];
for(let i=0;i<FPS*DURATION;i++){frames.push(draw(i/FPS));const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain');if(i%240===0)console.log(`${i}/${FPS*DURATION}`);}
ff.stdin.end();const [code]=await completion;if(code)throw Error('Encode failed '+code);
await writeFile(path.join(base,'motion-audit-v1.json'),JSON.stringify({frames,impacts,notes:'First animation draft, provisional bill timing. Fixed foot pixels verified separately.'},null,2)+'\n');console.log(`Rendered ${FPS*DURATION} frames / ${DURATION} seconds.`);
