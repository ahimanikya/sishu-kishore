"""Original synthesized breeze, two-note call sketch and six water taps. No speech or field recordings."""
from pathlib import Path
import json,wave
import numpy as np
root=Path(__file__).resolve().parent;sr=48000;duration=48;rng=np.random.default_rng(814)
track=np.zeros((sr*duration,2));events=[]
def place(sound,at,gain,pan,kind):
 start=round(at*sr);sound=sound*gain
 track[start:start+len(sound),0]+=sound*(1-pan)*.5
 track[start:start+len(sound),1]+=sound*(1+pan)*.5
 events.append({'kind':kind,'start':at,'duration':len(sound)/sr,'gain':gain,'pan':pan})
noise=rng.normal(0,1,sr*duration);air=np.convolve(noise,np.ones(121)/121,mode='same');air/=max(abs(air));t=np.arange(len(air))/sr
fade=np.minimum(1,np.minimum(t/1.5,(duration-t)/1.2));air*=fade*(.55+.18*np.sin(t*.7)+.12*np.sin(t*1.3))
place(air,0,.012,0,'breeze sketch')
calls=[(1.1,.45),(1.65,.6),(3.65,.45),(4.2,.6),(6.8,.45),(7.35,.6),(9.7,.45),(10.25,.6)]
for i,(at,length) in enumerate(calls):
 t=np.arange(round(length*sr))/sr;p=t/length;frequency=(625 if i%2==0 else 760)+(80 if i%2==0 else 95)*np.sin(np.pi*p/2)
 phase=2*np.pi*np.cumsum(frequency)/sr;env=np.sin(np.pi*p)**1.2
 sound=(np.sin(phase)+.11*np.sin(2*phase))*env
 place(sound,at,.13,-.35,'synthesized kuhu sketch')
for at in [4.2,19,24.6,32.5,42.2,46]:
 t=np.arange(round(.33*sr))/sr;env=np.exp(-t*22);sound=(np.sin(2*np.pi*1150*t)+.45*np.sin(2*np.pi*1830*t))*env
 sound+=.22*rng.normal(size=len(t))*np.exp(-t*95);sound*=np.minimum(1,t/.002)
 place(sound,at,.055 if at==4.2 else .095,.55,'water tap')
peak=np.max(abs(track));track*=10**(-18/20)/peak
samples=np.round(track*32767).astype('<i2')
with wave.open(str(root/'sound-draft-v1.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes(samples.tobytes())
report={'duration':duration,'sampleRate':sr,'channels':2,'source':'Original synthesized sound sketch; no recorded speech, music, wildlife or external samples. The call is a stylized two-note sketch, not a field recording.','peakDbFS':float(20*np.log10(np.max(abs(track)))),'rmsDbFS':float(20*np.log10(np.sqrt(np.mean(track**2)))),'clippedSamples':int(np.sum(abs(track)>=1)),'events':events}
(root/'sound-review-v1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='events'}))
