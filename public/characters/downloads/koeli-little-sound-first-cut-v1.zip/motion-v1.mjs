export const clamp=x=>Math.max(0,Math.min(1,x));
export const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
export const impacts=[4.2,19,24.6,32.5,42.2,46];
export const calls=[{at:1.1,duration:.45},{at:1.65,duration:.6},{at:3.65,duration:.45},{at:4.2,duration:.6},{at:6.8,duration:.45},{at:7.35,duration:.6},{at:9.7,duration:.45},{at:10.25,duration:.6}];
const blinkStarts=[6.15,11.7,17.8,23.6,31.4,35.3,41.1,47.2];
export function stateAt(t){
 const listen=ease((t-12.7)/2),lean=ease((t-23.6)/1.6)*(1-ease((t-34.3)/1.4)),last=ease((t-40.5)/1.5);
 const childLook=ease((t-35.7)/.8)*(1-ease((t-39.6)/.8));
 let opening=0;for(const c of calls){const p=(t-c.at)/c.duration;if(p>=0&&p<=1)opening=Math.max(opening,Math.sin(Math.PI*p)**.4);}
 // Provisional bill beats carry the written lines; final performance awaits voices.
 for(const [a,b] of [[.8,3.4],[25.5,30.5],[36.8,40.5]])if(t>=a&&t<=b)opening=Math.max(opening,(.3+.4*Math.sin((t-a)*8)**2)*ease((t-a)/.15)*ease((b-t)/.15));
 const blink=blinkStarts.some(a=>t>=a&&t<a+4/24)&&opening<.2;
 const breath=1.8*Math.sin(t*2.1),angle=-.07+.24*listen+.12*lean+.1*childLook-.08*last;
 let leafAngle=0;for(const at of impacts){const d=t-at;if(d>=0&&d<1.6)leafAngle-=.045*Math.exp(-3*d)*Math.sin(11*d);}
 return {t,listen,lean,last,childLook,opening,blink,breath,headAngle:angle,leafAngle,phase:t<12?'calling':t<24?'noticing':t<36?'discovering':'listening'};
}
export function bodyPoint(p,s){
 // Every source point at or below y=400, including both complete feet, stays fixed.
 const weight=ease((400-p[1])/285);
 return [p[0]+30+105*s.lean*weight,p[1]+160+(60*s.lean+s.breath)*weight];
}
export function leafPoint(p,s){const dx=(p[0]-620)*.8,dy=(p[1]-900)*.8,a=s.leafAngle;return [1440+dx*Math.cos(a)-dy*Math.sin(a),575+dx*Math.sin(a)+dy*Math.cos(a)];}
export function dropPoint(at,t){const p=clamp((t-(at-.72))/.72);return [1100,222+(630-222)*p*p];}
