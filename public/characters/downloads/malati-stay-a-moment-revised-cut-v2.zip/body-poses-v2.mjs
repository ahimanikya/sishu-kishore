import {mix,clamp} from './motion-v2.mjs';
export const bodyPoses=[
 {image:'standing',rect:[205,15,395,990],centres:[[400,50],[400,360],[400,650],[400,982]],feet:[[285,980],[515,984]],shoulders:[[245,125],[555,125]],neck:[400,60]},
 {image:'poses',rect:[120,30,530,730],centres:[[300,90],[435,320],[340,500],[392.5,707.5]],feet:[[225,695],[560,720]],shoulders:[[195,170],[450,135]],neck:[300,90]},
 {image:'poses',rect:[780,15,520,755],centres:[[985,60],[1110,350],[1010,480],[1035,721]],feet:[[900,704],[1170,738]],shoulders:[[885,145],[1135,130]],neck:[985,60]},
 {image:'poses',rect:[1365,15,570,770],centres:[[1685,65],[1760,365],[1590,480],[1600,743]],feet:[[1470,730],[1730,756]],shoulders:[[1575,150],[1810,145]],neck:[1685,65]}
];
export function skeleton(s){
 const stand=[[1050,260],[1050,440],[1050,620],[1050,801]],bend=[[980,530],[1050,665],[1020,735],[1050,801]],seat=[[980,400],[1010,615],[990,685],[1050,801]];
 return stand.map((p,i)=>mix(mix(p,bend[i],s.r.bend),seat[i],s.r.sit));
}
function level(g,p){
 const [a,b]=g.feet,slope=(b[1]-a[1])/(b[0]-a[0]),cy=p[1]-slope*(p[0]-g.centres[3][0]);
 const ys=g.centres.map(c=>c[1]-slope*(c[0]-g.centres[3][0]));
 let k=0;while(k<2&&cy>ys[k+1])k++;
 const u=(cy-ys[k])/(ys[k+1]-ys[k]);return {k,u};
}
export function posePoint(g,p,s){
 const target=skeleton(s),{k,u}=level(g,p),source=mix(g.centres[k],g.centres[k+1],u),at=mix(target[k],target[k+1],u),footScale=133.4/(g.feet[1][0]-g.feet[0][0]),width=k===2?.58+(footScale-.58)*clamp(u):.58;
 return [at[0]+(p[0]-source[0])*width,at[1]];
}
export function poseWeights(s){
 if(s.r.bend>0)return[1-s.r.bend,s.r.bend,0,0];
 const p=s.r.sit;if(p<.5){const u=p*2;return[1-u,0,u,0];}const u=(p-.5)*2;return[0,0,1-u,u];
}
export function blendedPoint(key,s){const weights=poseWeights(s);return bodyPoses.reduce((out,g,i)=>{const p=posePoint(g,g[key],s);return[out[0]+p[0]*weights[i],out[1]+p[1]*weights[i]];},[0,0]);}
export function shouldersAt(s){const weights=poseWeights(s);return[0,1].map(j=>bodyPoses.reduce((out,g,i)=>{const p=posePoint(g,g.shoulders[j],s);return[out[0]+p[0]*weights[i],out[1]+p[1]*weights[i]];},[0,0]));}
