import {createRequire} from 'node:module';
import {writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {stateAt,raghuPoint,malatiPoint,faceAt} from './motion-v2.mjs';
import {textureTriangle,skinArm,skinnedPoint} from './mesh-v2.mjs';
import {bodyPoses,posePoint,poseWeights,blendedPoint} from './body-poses-v2.mjs';
const require=createRequire(import.meta.url),{createCanvas,loadImage,GlobalFonts}=require(process.env.BOITA_CANVAS_MODULE||'@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url)),W=1536,H=1024,FPS=24,DURATION=56;
const [bg,r,m,parcel,rposes,rArms,mParts]=await Promise.all(['background-v1.png','raghu-rig-v1.png','malati-rig-v3.png','parcel-v1.png','raghu-body-poses-v1.png','raghu-connected-pose-v2.png','malati-rig-v4.png'].map(n=>loadImage(path.join(base,n))));
GlobalFonts.registerFromPath(path.join(base,'baloo-bhaina-2.ttf'),'Baloo Bhaina 2');
const canvas=createCanvas(W,H);let ctx=canvas.getContext('2d');const bodyCanvas=createCanvas(W,H),bodyContext=bodyCanvas.getContext('2d'),poseCanvas=createCanvas(W,H),poseContext=poseCanvas.getContext('2d');
function part(img,rect,anchor,at,scale,angle=0){const[x,y,w,h]=rect;ctx.save();ctx.translate(...at);ctx.rotate(angle);ctx.scale(scale,scale);ctx.drawImage(img,x,y,w,h,x-anchor[0],y-anchor[1],w,h);ctx.restore();}
function mesh(img,rect,map,nx=18,ny=32,clip=null){const[x,y,w,h]=rect;for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){const a=[[x+w*i/nx,y+h*j/ny],[x+w*(i+1)/nx,y+h*j/ny],[x+w*(i+1)/nx,y+h*(j+1)/ny],[x+w*i/nx,y+h*(j+1)/ny]],b=a.map(map);textureTriangle(ctx,img,[a[0],a[1],a[2]],[b[0],b[1],b[2]],clip);textureTriangle(ctx,img,[a[0],a[2],a[3]],[b[0],b[2],b[3]],clip);}}
function elbow(A,B,l1,l2,sign){const dx=B[0]-A[0],dy=B[1]-A[1],d=Math.max(.001,Math.hypot(dx,dy)),a=(l1*l1-l2*l2+d*d)/(2*d),h=Math.sqrt(Math.max(0,l1*l1-a*a));return[A[0]+dx*a/d-sign*dy*h/d,A[1]+dy*a/d+sign*dx*h/d];}
const armsR=[
 {rect:[245,275,185,445],a:[376,315],e:[310,550],b:[345,675],width:.58,l1:132,l2:133,sign:1,clip:[[335,280],[430,280],[420,365],[385,435],[365,510],[359,555],[349,585],[337,610],[350,630],[361,651],[370,660],[383,667],[394,662],[405,664],[410,670],[402,681],[384,694],[358,704],[334,706],[311,698],[293,685],[285,667],[282,640],[276,614],[267,578],[267,557],[278,532],[294,507],[306,462],[320,425],[334,397],[335,350]]},
 {rect:[455,290,360,440],a:[714,330],e:[742,555],b:[535,675],width:.58,l1:132,l2:133,sign:-1,clip:[[705,315],[732,313],[751,356],[780,440],[800,540],[794,583],[765,609],[720,630],[680,655],[641,678],[606,692],[575,707],[550,714],[521,716],[492,709],[470,695],[463,683],[470,676],[495,683],[513,679],[533,665],[524,660],[525,648],[535,640],[640,600],[700,545],[665,465],[665,390]]}];
const armsM=[
 {rect:[770,635,380,365],a:[830,680],e:[850,870],b:[1080,935],width:.43,l1:82,l2:110,sign:1,clip:[[770,635],[955,635],[955,800],[1150,1000],[770,1000]]},
 {rect:[1050,635,465,365],a:[1100,680],e:[1240,850],b:[1430,950],width:.43,l1:90,l2:108,sign:-1,clip:[[1045,635],[1250,635],[1535,1000],[1190,1000],[1035,760]]}];
function arms(img,defs,shoulders,hands){return defs.map((g,i)=>{const A=shoulders[i],B=hands[i],E=elbow(A,B,g.l1,g.l2,g.sign);skinArm(ctx,img,g,A,E,B);return{shoulder:A,elbow:E,hand:B,renderedHand:skinnedPoint(g.b,g,A,E,B),reach:Math.hypot(B[0]-A[0],B[1]-A[1]),maxReach:g.l1+g.l2};});}
const headsR=[{rect:[800,20,305,290],anchor:[970,285]},{rect:[1130,20,320,295],anchor:[1300,295]},{rect:[800,320,305,290],anchor:[970,575]},{rect:[1130,320,320,290],anchor:[1300,580]}];
const headsM=[{rect:[770,20,285,300],anchor:[935,300]},{rect:[1140,20,290,300],anchor:[1310,300]},{rect:[770,325,285,290],anchor:[930,595]},{rect:[1140,325,290,290],anchor:[1310,595]}];
function draw(t){
 const s=stateAt(t),rf=faceAt(t,'r'),mf=faceAt(t,'m');ctx.clearRect(0,0,W,H);ctx.drawImage(bg,0,0,W,H);
 const shadowFeet=[...bodyPoses[0].feet.map(p=>posePoint(bodyPoses[0],p,s)),...[[505,970],[605,945]].map(p=>malatiPoint(p,s))],ground=[801,801,797.75,787];shadowFeet.forEach((p,i)=>{const lift=Math.max(0,ground[i]-p[1]);ctx.fillStyle=`rgba(70,45,25,${.12/(1+lift*.05)})`;ctx.beginPath();ctx.ellipse(p[0],ground[i]+2,30-lift*.35,7,0,0,Math.PI*2);ctx.fill();});
 const weights=poseWeights(s),mainContext=ctx;bodyContext.clearRect(0,0,W,H);bodyContext.globalCompositeOperation='lighter';for(let i=0;i<4;i++){if(weights[i]<.001)continue;const g=bodyPoses[i];ctx=poseContext;ctx.clearRect(0,0,W,H);mesh(g.image==='standing'?r:rposes,g.rect,p=>posePoint(g,p,s));bodyContext.globalAlpha=weights[i];bodyContext.drawImage(poseCanvas,0,0);}bodyContext.globalAlpha=1;bodyContext.globalCompositeOperation='source-over';ctx=mainContext;ctx.drawImage(bodyCanvas,0,0);mesh(mParts,[60,75,670,930],p=>malatiPoint(p,s));
 const R=headsR[rf.pose],M=headsM[mf.pose];part(r,R.rect,R.anchor,blendedPoint('neck',s),.60,-.30*s.r.bend);
 const shake=t>19&&t<21?Math.sin((t-19)*Math.PI*3)*.035:0;part(m,M.rect,M.anchor,malatiPoint([380,125],s),.46,shake);
 ctx.fillStyle='rgba(65,43,23,.12)';if(!s.held){ctx.beginPath();ctx.ellipse(s.parcel[0],s.parcel[1],97,15,0,0,Math.PI*2);ctx.fill();}
 part(parcel,[200,180,1135,730],[768,887],s.parcel,.18);
 const ra=arms(rArms,armsR,s.rs,s.rh),ma=arms(mParts,armsM,s.ms,s.mh);
 ctx.fillStyle='rgba(250,246,232,.96)';ctx.fillRect(0,925,W,99);ctx.fillStyle='#273c35';ctx.font='30px "Baloo Bhaina 2"';ctx.fillText('ଆଉ ଟିକେ ବସ · ଚଳଚ୍ଚିତ୍ର ଖସଡ଼ା',42,964);ctx.font='22px sans-serif';ctx.fillText('Sit a Little Longer · Animation draft',42,997);ctx.textAlign='right';ctx.font='21px sans-serif';ctx.fillText('Concept and creative direction: Ahimanikya Satapathy',1494,966);ctx.font='22px "Baloo Bhaina 2"';ctx.fillText('ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା: Ahimanikya Satapathy',1494,998);ctx.textAlign='left';
 return{t,raghuHip:s.r.hip,bodyWeights:weights,raghuPoseFeet:bodyPoses.map((g,i)=>({pose:i,weight:weights[i],feet:g.feet.map(p=>posePoint(g,p,s))})),raghuFeet:bodyPoses[0].feet.map(p=>posePoint(bodyPoses[0],p,s)),malatiFeet:[[505,970],[605,945]].map(p=>malatiPoint(p,s)),malatiFootShapes:[[[470,930],[500,950],[550,975]],[[560,910],[610,935],[650,955]]].map(points=>points.map(p=>malatiPoint(p,s))),sit:s.sit,bend:s.r.bend,parcel:s.parcel,held:s.held,contact:s.contact,grip:s.grip,armsR:ra,armsM:ma,faces:{raghu:rf,malati:mf}};
}
await mkdir(path.join(base,'proof'),{recursive:true});
for(const t of [0,1.5,2.7,4,5.9,7.2,14,20,25.4,27.2,29,32.5,34.3,35.5,37.5,39,40.8,42.6,44,50,55.5]){draw(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'));}
if(process.argv.includes('--proof-only')){console.log('Proof frames saved.');process.exit(0);}
const ff=spawn(process.env.BOITA_FFMPEG||'ffmpeg',['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-i',path.join(base,'sound-draft-v1.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(DURATION),path.join(base,'sit-a-little-longer-revised-cut-v2.mp4')],{stdio:['pipe','inherit','inherit']});
const done=once(ff,'close'),audit=[];
for(let i=0;i<FPS*DURATION;i++){audit.push(draw(i/FPS));const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain');if(i%240===0)console.log(`${i}/${FPS*DURATION}`);}
ff.stdin.end();const[code]=await done;if(code)throw Error('Encode failed '+code);await writeFile(path.join(base,'motion-audit-v2.json'),JSON.stringify({frames:audit,notes:'Revised animation draft. Provisional dialogue timings; no recorded voice. Cloth deformation and contact are drawing approximations.'},null,2)+'\n');console.log(`Rendered ${FPS*DURATION} frames / ${DURATION} seconds.`);
