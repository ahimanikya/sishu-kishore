"""Original synthesized effects for the wordless animated first cut. No field samples."""
from pathlib import Path
import json, wave
import numpy as np
BASE=Path(__file__).resolve().parent
SR=48000;DURATION=50
rng=np.random.default_rng(20261018)
n=SR*DURATION
t=np.arange(n)/SR
noise=rng.normal(0,1,n)
air=np.convolve(noise,np.ones(90)/90,mode='same')
track=air*.012*(.7+.2*np.sin(t*.31))
events=[]
def rustle(at,duration,amplitude,kind,pan=0):
    count=int(SR*duration);u=np.arange(count)/SR
    raw=rng.normal(0,1,count)
    shaped=np.convolve(raw,np.ones(9)/9,mode='same')
    env=np.sin(np.pi*np.arange(count)/count)**2
    signal=shaped*env*amplitude
    start=int(at*SR);track[start:start+count]+=signal
    events.append({'at':round(at,3),'seconds':duration,'kind':kind})
def tap(at,amplitude,kind):
    count=int(SR*.09);u=np.arange(count)/SR
    signal=(np.sin(2*np.pi*850*u)+.3*rng.normal(0,1,count))*np.exp(-u*85)*amplitude
    start=int(at*SR);track[start:start+count]+=signal
    events.append({'at':round(at,3),'seconds':.09,'kind':kind})
for start,end in [(1,11.6),(38.6,49)]:
    at=start
    while at<end:
        rustle(at,.09,.065,'nibble')
        at+=float(rng.uniform(.35,.65))
for at,amp in [(12.52,.1),(12.76,.065),(13.02,.045),(13.32,.03),(13.68,.02)]:tap(at,amp,'seed')
for at in [15.3,15.65,16.1,19.8,20.2,20.7]:rustle(at,.18,.035,'reaching paw')
for at in np.arange(25.5,32.5,.25):rustle(float(at),.075,.035,'walking paw')
rustle(36.55,.18,.035,'seed pickup')
rustle(42,.4,.025,'folding cloth')
for at in [3.2,8.9,18.2,23.5,34.1,45.7]:rustle(at,1.0,.009,'distant leaves')
fade=np.minimum(1,np.minimum(t/.6,(DURATION-t)/.8));track*=fade
peak=float(np.max(np.abs(track)))
stereo=np.column_stack([track,track*.97])
pcm=(np.clip(stereo,-1,1)*32767).astype('<i2')
with wave.open(str(BASE/'sound-v1.wav'),'wb') as f:
    f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR);f.writeframes(pcm.tobytes())
(BASE/'sound-review-v1.json').write_text(json.dumps({'duration':DURATION,'sampleRate':SR,'channels':2,'source':'Original deterministic synthesized sound sketch, no field samples or speech','peakDbFS':round(20*np.log10(peak),2),'rmsDbFS':round(20*np.log10(np.sqrt(np.mean(track**2))),2),'clippedSamples':int((np.abs(track)>=1).sum()),'events':events},indent=2)+'\n')
print('Created 50-second stereo sound sketch; peak',round(20*np.log10(peak),2),'dBFS; no speech.')
