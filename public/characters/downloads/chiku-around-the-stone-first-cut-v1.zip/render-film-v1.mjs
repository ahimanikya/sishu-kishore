import {createRequire} from 'node:module';
import {writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
const require=createRequire(import.meta.url);
const {createCanvas,loadImage,GlobalFonts}=require(process.env.CHIKU_CANVAS_MODULE || '@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url));
GlobalFonts.registerFromPath(path.join(base,'baloo-bhaina-2.ttf'),'FilmOdia');
const [bg,poses,props]=await Promise.all(['background-v1.png','poses-v2.png','props-children-v1.png'].map(n=>loadImage(path.join(base,n))));
const W=1536,H=1024,FPS=24,DURATION=50;
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d');
// Source rectangles include complete transparent silhouettes, with a gap between rows.
const cells=[
 [0,0,530,425,300,400],[530,0,494,425,825,400],
 [0,425,530,370,180,770],[530,425,494,370,660,770],
 [0,795,535,340,280,1105],[535,795,489,340,810,1120],
 [0,1135,535,401,280,1455],[535,1135,489,401,810,1450]
];
const clamp=x=>Math.max(0,Math.min(1,x));
const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
const lerp=(a,b,t)=>a+(b-a)*t;
const blinks=[2.8,8.4,11.1,40.2,44.7,48.2];
function sprite(i,px,py,scale=1,angle=0){
 const [x,y,w,h,ax,ay]=cells[i];ctx.save();ctx.translate(px,py);ctx.rotate(angle);ctx.scale(scale,scale);ctx.drawImage(poses,x,y,w,h,x-ax,y-ay,w,h);ctx.restore();
}
function shadow(x,y,rx,ry,alpha=.13){ctx.save();ctx.fillStyle=`rgba(65,48,25,${alpha})`;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fill();ctx.restore()}
function stone(){shadow(820,865,182,19,.2);ctx.drawImage(props,370,35,430,170,635,724,370,146)}
function seed(x,y,angle=0){ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.drawImage(props,1010,100,110,65,-15,-9,30,18);ctx.restore()}
function kids(t){
 // Two hand-drawn key poses: the bag folds once, then they smooth it together.
 const folded=t>=42;
 const r=folded?[500,640,510,380]:[500,225,510,415];
 const [x,y,w,h]=r; const dw=270,dh=h*dw/w;
 const sway=.0025*Math.sin(t*1.2);
 ctx.save();ctx.translate(1180,470);ctx.rotate(sway);ctx.drawImage(props,x,y,w,h,-dw/2,-dh,dw,dh);ctx.restore();
}
function seated(t,x,y,s=1){
 const blink=blinks.some(at=>t>=at&&t<at+.17);
 const breath=1+.0022*Math.sin(t*2.4);
 ctx.save();ctx.translate(x,y);ctx.scale(1,breath);sprite(blink?1:0,0,0,s);ctx.restore();
}
function render(t){
 ctx.clearRect(0,0,W,H);ctx.save();
 if(t>=38.3){ctx.scale(1.4,1.4);ctx.translate(-400,-200)}
 ctx.drawImage(bg,0,0,W,H);kids(t);
 // The same stone and seed positions persist across the entire sequence.
 if(t<12){
  shadow(450,864,135,19);seated(t,450,864,.96);stone();
 } else if(t<24){
  const dt=t-12;
  // Drop, short bounce and roll behind the stone to its right-hand side.
  const p=ease(dt/2.4);const sx=lerp(580,1105,p);
  let sy=dt<.52?lerp(705,852,(dt/.52)**2):852-15*Math.exp(-2.7*(dt-.52))*Math.abs(Math.sin((dt-.52)*12));
  seed(sx,sy,p*10);
  const reaching=(t>=15.2&&t<17)||(t>=19.7&&t<21.7);
  shadow(400,864,145,17);sprite(reaching?3:2,325+(reaching?5:0),864,.96);stone();
 } else if(t<36){
  seed(1105,852,10);
  const p=clamp((t-25.5)/7);
  const x=lerp(450,895,p),y=864-100*Math.sin(p*Math.PI);
  shadow(x,y,115,13,.1);
  if(t<25.5)sprite(2,325,864,.96);
  else if(p<1){
   const phase=[4,5,7,6][Math.floor((t-25.5)*8)%4];
   sprite(phase,x,y,.88);
  }else sprite(5,895,864,.88);
  stone();
 } else if(t<38.3){
  const p=ease((t-36)/1.3);
  shadow(840,864,130,17);sprite(3,lerp(785,803,p),864,.96);
  // The forepaw meets the seed; the next cut reveals it held on the stone.
  seed(1105-2*p,852-5*p,10);stone();
 } else {
  stone();
  shadow(818,739,76,9,.12);seated(t,810,741,.91);
 }
 ctx.restore();
 if(t<3.8 || (t>=45&&t<49.2)){
  ctx.save();ctx.fillStyle='rgba(253,248,233,.93)';ctx.fillRect(55,48,700,142);ctx.fillStyle='#35382a';
  ctx.font='38px FilmOdia';
  ctx.fillText(t<3.8?'ପଥରର ଅନ୍ୟ ପଟେ':'ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା',80,104);
  ctx.font='27px FilmOdia';ctx.fillText(t<3.8?'Around the Stone':'Concept and creative direction: Ahimanikya Satapathy',80,153);ctx.restore();
 }
 // A short natural fade ends the first cut; it never auto-loops.
 if(t>49.2){ctx.fillStyle=`rgba(34,29,23,${ease((t-49.2)/.8)})`;ctx.fillRect(0,0,W,H)}
}
await mkdir(path.join(base,'proof'),{recursive:true});
const proofs=[0,8.46,12.25,13.2,14.5,16,24.5,26.1,27.1,28.1,29.1,30.1,31.1,32.8,36.7,39,42.2,47];
for(const t of proofs){render(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'))}
if(process.argv.includes('--proof-only')){console.log('Saved '+proofs.length+' narrative frame proofs.');process.exit(0)}
const ffmpeg=process.env.CHIKU_FFMPEG || 'ffmpeg';
const ff=spawn(ffmpeg,['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-i',path.join(base,'sound-v1.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(DURATION),path.join(base,'around-the-stone-first-cut-v1.mp4')],{stdio:['pipe','inherit','inherit']});
const completion=once(ff,'close');
for(let i=0;i<FPS*DURATION;i++){render(i/FPS);const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain');if(i%(FPS*10)===0)console.log('Rendered '+i/FPS+' seconds')}
ff.stdin.end();const [code]=await completion;if(code!==0)throw Error('Encode failed '+code);
console.log('Rendered 1200 frames / 50 seconds.');
