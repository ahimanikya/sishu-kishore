import {createRequire} from 'node:module';
import {writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {makePuppet} from './puppet.mjs';
import {stateAt,footAt,ease} from './motion-v3.mjs';
const require=createRequire(import.meta.url);
const {createCanvas,loadImage,GlobalFonts}=require(process.env.CHIKU_CANVAS_MODULE||'@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url));
GlobalFonts.registerFromPath(path.join(base,'baloo-bhaina-2.ttf'),'FilmOdia');
const [bg,rig,heads,props,children]=await Promise.all(['background-v1.png','puppet-v1.png','heads-v1.png','props-children-v1.png','children-v2.png'].map(n=>loadImage(path.join(base,n))));
const W=1536,H=1024,FPS=24,DURATION=50;
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d'),pup=makePuppet(ctx,rig,heads);
function shadow(x,y,rx,ry,alpha=.13){ctx.save();ctx.fillStyle=`rgba(65,48,25,${alpha})`;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fill();ctx.restore()}
function stone(){shadow(820,865,182,19,.2);ctx.drawImage(props,370,35,430,170,635,724,370,146)}
function seed(pt,angle=0){ctx.save();ctx.translate(...pt);ctx.rotate(angle);ctx.drawImage(props,1010,100,110,65,-15,-9,30,18);ctx.restore()}
function kids(t){
 const phase=t<42?0:t<43?1:t<44.2?2:3;
 const r=[[150,15,610,490],[810,15,630,490],[150,525,610,475],[860,525,600,475]][phase];
 const [x,y,w,h]=r,dw=270,dh=h*dw/w;
 ctx.drawImage(children,x,y,w,h,1180-dw/2,470-dh,dw,dh);
}
function render(t){
 ctx.clearRect(0,0,W,H);ctx.save();const zoom=ease((t-40.6)/1.6);ctx.translate(-560*zoom,-280*zoom);ctx.scale(1+.4*zoom,1+.4*zoom);
 ctx.drawImage(bg,0,0,W,H);kids(t);
 const state=stateAt(t),[x,y]=state.root;
 if(state.aboveStone){stone();shadow(865,751,65,8,.11)}else shadow(x+40,864,130,15,state.phase==='hop'?.06:.12);
 pup.pose({x,y,upright:state.upright,feet:state.feet,nearPaw:state.nearPaw,farPaw:state.farPaw,t,headAngle:state.headAngle,expression:state.expression});
 seed(state.seed,state.seedAngle);
 if(!state.aboveStone)stone();
 ctx.restore();
 if(t<3.8||(t>=45&&t<49.2)){
  ctx.save();ctx.fillStyle='rgba(253,248,233,.93)';ctx.fillRect(55,48,700,142);ctx.fillStyle='#35382a';
  ctx.font='38px FilmOdia';ctx.fillText(t<3.8?'ପଥରର ଅନ୍ୟ ପଟେ':'ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା',80,104);
  ctx.font='27px FilmOdia';ctx.fillText(t<3.8?'Around the Stone':'Concept and creative direction: Ahimanikya Satapathy',80,153);ctx.restore();
 }
 if(t>49.2){ctx.fillStyle=`rgba(34,29,23,${ease((t-49.2)/.8)})`;ctx.fillRect(0,0,W,H)}
}
await mkdir(path.join(base,'proof'),{recursive:true});
const proofs=[0,8.46,12,12.3,12.6,13,16,24.5,26.1,28.1,30.1,32.8,36.6,37.3,38,38.5,39.1,39.45,39.65,39.85,40.05,40.35,40.5,41,42.5,44.5,47];
for(const t of proofs){render(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'))}
const audit={frames:[],stanceSamples:[]};
for(let i=0;i<FPS*DURATION;i++){const t=i/FPS;audit.frames.push(stateAt(t));if(t>=25.5&&t<=32.5)for(let leg=0;leg<4;leg++)audit.stanceSamples.push({t,leg,...footAt(t,leg)})}
await writeFile(path.join(base,'motion-contact-audit-v3.json'),JSON.stringify(audit,null,2)+'\n');
if(process.argv.includes('--proof-only')){console.log('Saved '+proofs.length+' frame proofs and motion audit.');process.exit(0)}
const start=process.argv.includes('--transition-test')?36:0,duration=process.argv.includes('--transition-test')?7:DURATION;
const output=process.argv.includes('--transition-test')?'transition-test-v3.mp4':'around-the-stone-edition-v3.mp4';
const ff=spawn(process.env.CHIKU_FFMPEG||'ffmpeg',['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-ss',String(start),'-i',path.join(base,'sound-v3.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(duration),path.join(base,output)],{stdio:['pipe','inherit','inherit']});
const complete=once(ff,'close');
for(let i=0;i<FPS*duration;i++){render(start+i/FPS);const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain');if(i%(FPS*10)===0)console.log('Rendered '+i/FPS+' seconds')}
ff.stdin.end();const [code]=await complete;if(code!==0)throw Error('Encode failed '+code);
console.log('Rendered '+duration+' seconds to '+output);
