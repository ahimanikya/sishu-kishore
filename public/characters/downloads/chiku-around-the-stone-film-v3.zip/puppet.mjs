// One continuous articulated pose; original source raster assets are unchanged.
export function makePuppet(ctx,rig,heads){
 const rect={body:[70,75,510,285],tail:[60,365,480,420],upper:[640,420,250,335],holding:[180,785,235,290],thigh:[610,780,310,285],shin:[100,1120,205,235],hindfoot:[150,1340,230,95]};
 const mix=(a,b,p)=>a.map((v,i)=>v+(b[i]-v)*p);
 function part(name,point,anchor,scale=1,angle=0){const [x,y,w,h]=rect[name];ctx.save();ctx.translate(...point);ctx.rotate(angle);ctx.scale(...(Array.isArray(scale)?scale:[scale,scale]));ctx.drawImage(rig,x,y,w,h,x-anchor[0],y-anchor[1],w,h);ctx.restore()}
 function bone(name,a,b,sa,sb,width=1){
  const ta=Math.atan2(b[1]-a[1],b[0]-a[0]),aa=Math.atan2(sb[1]-sa[1],sb[0]-sa[0]);
  const scale=Math.hypot(b[0]-a[0],b[1]-a[1])/Math.hypot(sb[0]-sa[0],sb[1]-sa[1]);
  const [x,y,w,h]=rect[name];ctx.save();ctx.translate(...a);ctx.rotate(ta);ctx.scale(scale,scale*width);ctx.rotate(-aa);ctx.drawImage(rig,x,y,w,h,x-sa[0],y-sa[1],w,h);ctx.restore();
 }
 function ik(a,b,l1,l2,bend=1){const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.min(l1+l2-.001,Math.max(.001,Math.hypot(dx,dy)));const theta=Math.atan2(dy,dx)+bend*Math.acos(Math.max(-1,Math.min(1,(l1*l1+d*d-l2*l2)/(2*l1*d))));return [a[0]+l1*Math.cos(theta),a[1]+l1*Math.sin(theta)]}
 function hind(root,toe,upright){const ankle=[toe[0]-32,toe[1]-19],j=mix(ik(root,ankle,65,70,1),ik(root,ankle,65,70,-1),upright);bone('shin',j,ankle,[200,1190],[188,1345],.6);bone('thigh',root,j,[700,860],[820,1015],.75);part('hindfoot',toe,[300,1415],.28)}
 function arm(root,paw){const j=ik(root,paw,65,74);bone('holding',j,paw,[265,825],[361,1043],.78);bone('upper',root,j,[753,480],[814,707],.78)}
 function head(point,angle,expression){const sx=[0,700,1398][expression];ctx.save();ctx.translate(...point);ctx.rotate(angle);ctx.scale(.26,.26);ctx.drawImage(heads,sx,0,700,749,-125,-615,700,749);ctx.restore()}
 return {pose({x,y,upright=0,feet,nearPaw=null,farPaw=null,t=0,headAngle=.15,expression=0,bodyLean=0}){
  const p=upright,f=feet.map(pt=>[pt[0]-x,pt[1]-y]),near=nearPaw?[nearPaw[0]-x,nearPaw[1]-y]:f[2],far=farPaw?[farPaw[0]-x,farPaw[1]-y]:f[3];
  ctx.save();ctx.translate(x,y);
  hind(mix([-5,-92],[-35,-64],p),f[1],p);hind(mix([6,-85],[-25,-57],p),f[0],p);
  arm(mix([135,-102],[58,-119],p),far);
  part('tail',mix([-42,-85],[-42,-42],p),[460,740],.6,-.2*(1-p)+.025*Math.sin(t*1.4));
  part('body',[-10*p,-100+48*p],[205,235],[.52*(1-.15*p),.52],-.55*p+bodyLean);
  head(mix([136,-107],[65,-150],p),headAngle,expression);
  part('hindfoot',f[0],[300,1415],.28);
  arm(mix([137,-98],[73,-105],p),near);
  ctx.restore();
 }};
}
