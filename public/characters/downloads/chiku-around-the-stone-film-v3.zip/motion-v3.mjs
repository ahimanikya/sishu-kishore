export const clamp=x=>Math.max(0,Math.min(1,x));
export const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
export const lerp=(a,b,p)=>a+(b-a)*p;
export const mix=(a,b,p)=>a.map((v,i)=>lerp(v,b[i],p));
const offsets=[[35,0],[28,-8],[150,0],[150,-8]],phases=[0,.5,.5,0],stance=.65;
export function rootAt(t){const p=clamp((t-25.5)/7);return [lerp(375,895,p),864-100*Math.sin(p*Math.PI)]}
export function footAt(t,i){
 const q=t-25.5+phases[i],cycle=Math.floor(q),phase=q-cycle,start=25.5+cycle-phases[i];
 const contact=at=>{const r=rootAt(at+stance/2);return [r[0]+offsets[i][0],r[1]+offsets[i][1]]};
 const a=contact(start),b=contact(start+1);
 if(phase<stance)return {point:a,stance:true,cycle};
 const u=(phase-stance)/(1-stance),v=ease(u),point=mix(a,b,v);point[1]-=20*Math.sin(Math.PI*u);
 return {point,stance:false,cycle};
}
function feetAt(t){
 const placement=(a,b,q)=>{const p=mix(a,b,ease(q));if(Math.hypot(b[0]-a[0],b[1]-a[1])>1)p[1]-=8*Math.sin(Math.PI*clamp(q));return p};
 if(t<25.5){const neutral=offsets.map(o=>[375+o[0],864+o[1]]);return neutral.map((a,i)=>placement(a,footAt(25.5,i).point,(t-24.9)/.6))}
 if(t>32.5)return offsets.map((o,i)=>placement(footAt(32.5,i).point,[895+o[0],864+o[1]],(t-32.5)/.65));
 return offsets.map((_,i)=>footAt(t,i).point);
}
const blinks=[2.8,8.4,11.1,18.7,24.3,33.8,41.2,44.7,48.2];
function expression(t,nibble){if(blinks.some(at=>t>=at&&t<at+.125))return 1;return nibble&&Math.sin(t*13.2)+.3*Math.sin(t*6.1)>.42?2:0}
export function stateAt(t){
 let root=rootAt(t),upright=0,feet=feetAt(t),nearPaw=null,farPaw=null,seed=[1105,852],seedAngle=10,held=false,aboveStone=false,headAngle=.2,phase='walk';
 const nibble=t<12||t>=41;
 if(t<12){upright=1;seed=[558,684];nearPaw=seed;farPaw=[552,676];held=true;seedAngle=.2;headAngle=.1;phase='nibble'}
 else if(t<24){
  upright=1-ease((t-12.1)/1.1);const dt=t-12,p=ease(dt/2.4);
  seed=[lerp(558,1105,p),dt<.52?lerp(684,852,(dt/.52)**2):852-15*Math.exp(-2.7*(dt-.52))*Math.abs(Math.sin((dt-.52)*12))];seedAngle=p*10;
  const reach=Math.max(ease((t-15.2)/.5)*(1-ease((t-16.4)/.5)),ease((t-19.7)/.5)*(1-ease((t-21)/.5)));
  nearPaw=mix(mix([525,864],[613,825],reach),[558,684],upright);farPaw=mix([525,856],[552,676],upright);headAngle=.2-.1*upright;phase=t<13.2?'lowering':'reach';
 }else if(t<36){headAngle=.2+.1*ease((t-34.8)/1);phase=t<25.5?'pause':'walk'}
 else if(t<38){
  headAngle=.3;phase='pickup';
  nearPaw=t<36.6?mix([1045,864],[1105,852],ease((t-36)/.6)):mix([1105,852],[1150,755],ease((t-36.75)/1.25));
  if(t>=36.6){held=true;seed=nearPaw;seedAngle=lerp(10,.2,ease((t-36.75)/1.25))}
 }else{
  upright=ease((t-38)/1.1);phase='rising';
  if(t>=39.1&&t<39.5){const q=ease((t-39.1)/.4);upright=1-.15*q;root=[895,864+8*q];phase='anticipation'}
  else if(t>=39.5&&t<40.35){
   const q=(t-39.5)/.85;root=[lerp(895,865,ease(q)),lerp(872,736,q)-95*Math.sin(Math.PI*q)];upright=.85+.15*ease(q/.5);
   feet=[[root[0]+35,root[1]-8*(1-q)+14*q-16*Math.sin(Math.PI*q)],[root[0]+28,root[1]-16*(1-q)+8*q-16*Math.sin(Math.PI*q)],[root[0]+150,root[1]],[root[0]+150,root[1]-8]];
   aboveStone=t>=39.84;phase='hop';
  }else if(t>=40.35){
   const q=clamp((t-40.35)/.25),settle=Math.sin(Math.PI*q);root=[865,736+4*settle];upright=1-.05*settle;feet=[[900,750],[893,744],[1015,750],[1015,744]];aboveStone=true;phase=t<40.6?'landing':'nibble';
  }
  const carry=mix([255,-109],[183,-180],upright);seed=[root[0]+carry[0],root[1]+carry[1]];nearPaw=seed;held=true;seedAngle=.2;headAngle=.3-.2*upright;
  const farHold=[seed[0]-6,seed[1]-8];farPaw=mix([1045,856],farHold,ease((t-38)/1.1));
 }
 if(nibble){const chew=expression(t,true)===2;seed=[seed[0]+(chew?.6:0),seed[1]+(chew?.8:0)];nearPaw=seed;farPaw=[seed[0]-6,seed[1]-8];headAngle+=.009*Math.sin(t*4.2);seedAngle+=.025*Math.sin(t*5)}
 return {t,root,upright,feet,nearPaw,farPaw,seed,seedAngle,held,aboveStone,headAngle,expression:expression(t,nibble),phase};
}
