// Painted cutout pieces animated with joint constraints. The source PNG is unchanged.
export function makePuppet(ctx,rig,heads,limbs){
 const rect={body:[70,75,510,285],head:[620,65,404,310],tail:[60,365,480,420],upper:[640,420,250,335],holding:[180,785,235,290],lower:[350,40,250,420],forefoot:[850,230,400,200],thigh:[610,780,310,285],shin:[100,1120,205,235],hindfoot:[150,1340,230,95],sit:[530,1080,450,400]};
 const source=name=>['lower','forefoot'].includes(name)?limbs:rig;
 function part(name,point,anchor,scale=1,angle=0){let [x,y,w,h]=rect[name];ctx.save();ctx.translate(...point);ctx.rotate(angle);ctx.scale(scale,scale);ctx.drawImage(source(name),x,y,w,h,x-anchor[0],y-anchor[1],w,h);ctx.restore()}
 function bone(name,a,b,sa,sb,width=1){
  const targetAngle=Math.atan2(b[1]-a[1],b[0]-a[0]),sourceAngle=Math.atan2(sb[1]-sa[1],sb[0]-sa[0]);
  const scale=Math.hypot(b[0]-a[0],b[1]-a[1])/Math.hypot(sb[0]-sa[0],sb[1]-sa[1]);
  // Scale in the bone's local frame so joint centres stay exact.
  const [x,y,w,h]=rect[name];ctx.save();ctx.translate(...a);ctx.rotate(targetAngle);ctx.scale(scale,scale*width);ctx.rotate(-sourceAngle);ctx.drawImage(source(name),x,y,w,h,x-sa[0],y-sa[1],w,h);ctx.restore();
 }
 function ik(a,b,l1,l2,bend){let dx=b[0]-a[0],dy=b[1]-a[1],d=Math.min(l1+l2-.001,Math.max(.001,Math.hypot(dx,dy)));let theta=Math.atan2(dy,dx)+bend*Math.acos(Math.max(-1,Math.min(1,(l1*l1+d*d-l2*l2)/(2*l1*d))));return [a[0]+l1*Math.cos(theta),a[1]+l1*Math.sin(theta)]}
 function leg(type,root,foot,bend=1){
  const hind=type==='hind';const ankle=[foot[0]-(hind?32:18),foot[1]-(hind?19:7)];
  const joint=ik(root,ankle,hind?65:60,hind?70:64,bend);
  if(hind){bone('shin',joint,ankle,[200,1190],[188,1345],.6);bone('thigh',root,joint,[700,860],[820,1015],.75);part('hindfoot',foot,[300,1415],.28)}
  else{bone('holding',joint,foot,[265,825],[361,1043],.85);bone('upper',root,joint,[753,480],[814,707],.85)}
 }
 function arm(root,paw,bend=1){const j=ik(root,paw,65,70,bend);bone('holding',j,paw,[265,825],[361,1043],.75);bone('upper',root,j,[753,480],[814,707],.7)}
 function head(point,angle=0,expression=0){
  if(!heads){part('head',point,[700,318],.42,angle);return}
  const x=[0,700,1398][expression];ctx.save();ctx.translate(...point);ctx.rotate(angle);ctx.scale(.26,.26);ctx.drawImage(heads,x,0,700,749,-125,-615,700,749);ctx.restore();
 }
 return {
  sit({x,y,t=0,seedPoint=[185,-175],headAngle=0,expression=0}){
   ctx.save();ctx.translate(x,y);
   part('tail',[-42,-42],[460,740],.6,.025*Math.sin(t*1.4));
   arm([58,-119],[seedPoint[0]-6,seedPoint[1]-8],1);
   part('sit',[0,0],[735,1438],.56);
   head([65,-150],headAngle,expression);
   arm([73,-105],seedPoint,1);
   ctx.restore();
  },
  walk({x,y,feet,t=0,headAngle=.15,expression=0,frontReach=null}){
   ctx.save();ctx.translate(x,y);
   const f=feet.map(p=>[p[0]-x,p[1]-y]);
   leg('hind',[-5,-92],f[1],1);leg('hind',[6,-85],f[0],1);leg('fore',[135,-102],f[3],1);
   part('tail',[-42,-85],[460,740],.6,-.2+.035*Math.sin(t*2));
   part('body',[0,-100],[205,235],.52);
   head([136,-107],headAngle,expression);
   if(frontReach)arm([135,-97],[frontReach[0]-x,frontReach[1]-y],1);
   else leg('fore',[137,-98],f[2],1);
   ctx.restore();
  },head,part
 }
}
