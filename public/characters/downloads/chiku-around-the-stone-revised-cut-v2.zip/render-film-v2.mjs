import {createRequire} from 'node:module';
import {writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {makePuppet} from './puppet.mjs';
const require=createRequire(import.meta.url);
const {createCanvas,loadImage,GlobalFonts}=require(process.env.CHIKU_CANVAS_MODULE||'@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url));
GlobalFonts.registerFromPath(path.join(base,'baloo-bhaina-2.ttf'),'FilmOdia');
const [bg,rig,heads,limbs,props,children]=await Promise.all(['background-v1.png','puppet-v1.png','heads-v1.png','limbs-v1.png','props-children-v1.png','children-v2.png'].map(n=>loadImage(path.join(base,n))));
const W=1536,H=1024,FPS=24,DURATION=50;
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d'),pup=makePuppet(ctx,rig,heads,limbs);
const clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},lerp=(a,b,p)=>a+(b-a)*p;
const mix=(a,b,p)=>a.map((v,i)=>lerp(v,b[i],p));
const blinkTimes=[2.8,8.4,11.1,18.7,24.3,33.8,40.2,44.7,48.2];
function expression(t,nibbling=false){if(blinkTimes.some(at=>t>=at&&t<at+.125))return 1;return nibbling&&Math.sin(t*13.2)+.3*Math.sin(t*6.1)>.42?2:0}
function shadow(x,y,rx,ry,alpha=.13){ctx.save();ctx.fillStyle=`rgba(65,48,25,${alpha})`;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fill();ctx.restore()}
function stone(){shadow(820,865,182,19,.2);ctx.drawImage(props,370,35,430,170,635,724,370,146)}
function seed(pt,angle=0){ctx.save();ctx.translate(...pt);ctx.rotate(angle);ctx.drawImage(props,1010,100,110,65,-15,-9,30,18);ctx.restore()}
function kids(t){
 const phase=t<40?0:t<41?1:t<42.2?2:3;
 const r=[[150,15,610,490],[810,15,630,490],[150,525,610,475],[860,525,600,475]][phase];
 const [x,y,w,h]=r,dw=270,dh=h*dw/w;
 ctx.drawImage(children,x,y,w,h,1180-dw/2,470-dh,dw,dh);
}
function rootAt(t){const p=clamp((t-25.5)/7);return [lerp(375,895,p),864-100*Math.sin(p*Math.PI)]}
const offsets=[[6,0],[-5,-8],[150,0],[150,-8]],phases=[0,.5,.5,0],stance=.65;
function footAt(t,i){
 const q=t-25.5+phases[i],cycle=Math.floor(q),phase=q-cycle,start=25.5+cycle-phases[i];
 const contact=at=>{const r=rootAt(at+stance/2);return [r[0]+offsets[i][0],r[1]+offsets[i][1]]};
 const a=contact(start),b=contact(start+1);
 if(phase<stance)return {point:a,stance:true,cycle};
 const u=(phase-stance)/(1-stance),v=ease(u),point=mix(a,b,v);point[1]-=20*Math.sin(Math.PI*u);
 return {point,stance:false,cycle};
}
function feetAt(t){
 if(t<25.5){const neutral=offsets.map(o=>[375+o[0],864+o[1]]);return neutral.map((a,i)=>mix(a,footAt(25.5,i).point,ease((t-24.9)/.6)))}
 if(t>32.5)return offsets.map((o,i)=>mix(footAt(32.5,i).point,[895+o[0],864+o[1]],ease((t-32.5)/.65)));
 return offsets.map((_,i)=>footAt(t,i).point);
}
function seated(t,x,y){
 const chew=expression(t,true)===2,point=[183+(chew?.6:0),-180+(chew?.8:0)];
 pup.sit({x,y,t,seedPoint:point,headAngle:.1+.009*Math.sin(t*4.2),expression:expression(t,true)});
 seed([x+point[0],y+point[1]],.2+.025*Math.sin(t*5));
}
function pickup(t){
 const reach=mix([1045,864],[1105,852],ease((t-36)/.6));
 const lift=mix([1105,852],[1150,755],ease((t-36.75)/1.25));
 return t<36.6?{paw:reach,seed:[1105,852],held:false}:{paw:lift,seed:lift,held:true};
}
function render(t){
 ctx.clearRect(0,0,W,H);ctx.save();if(t>=38.5){ctx.scale(1.4,1.4);ctx.translate(-400,-200)}
 ctx.drawImage(bg,0,0,W,H);kids(t);
 if(t<12){shadow(375,864,126,17);seated(t,375,864);stone()}
 else if(t<24){
  const dt=t-12,progress=ease(dt/2.4),sx=lerp(558,1105,progress);
  const sy=dt<.52?lerp(684,852,(dt/.52)**2):852-15*Math.exp(-2.7*(dt-.52))*Math.abs(Math.sin((dt-.52)*12));
  seed([sx,sy],progress*10);
  const a=ease((t-15.2)/.5)*(1-ease((t-16.4)/.5)),b=ease((t-19.7)/.5)*(1-ease((t-21)/.5));
  const amount=Math.max(a,b),reach=mix([525,864],[613,825],amount);
  shadow(405,864,137,17);pup.walk({x:375,y:864,t,feet:offsets.map(o=>[375+o[0],864+o[1]]),headAngle:.2,expression:expression(t),frontReach:reach});stone();
 }else if(t<36){
  seed([1105,852],10);const r=rootAt(t);shadow(r[0]+65,r[1],135,14,.12);
  pup.walk({x:r[0],y:r[1],t,feet:feetAt(t),headAngle:.17,expression:expression(t)});stone();
 }else if(t<38.5){
  const action=pickup(t);shadow(950,864,135,14,.12);
  pup.walk({x:895,y:864,t,feet:feetAt(t),headAngle:.3,frontReach:action.paw,expression:expression(t)});
  seed(action.seed,lerp(10,.2,ease((t-36.75)/1.25)));stone();
 }else{stone();shadow(818,739,76,9,.12);seated(t,810,741)}
 ctx.restore();
 if(t<3.8||(t>=45&&t<49.2)){
  ctx.save();ctx.fillStyle='rgba(253,248,233,.93)';ctx.fillRect(55,48,700,142);ctx.fillStyle='#35382a';
  ctx.font='38px FilmOdia';ctx.fillText(t<3.8?'ପଥରର ଅନ୍ୟ ପଟେ':'ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା',80,104);
  ctx.font='27px FilmOdia';ctx.fillText(t<3.8?'Around the Stone':'Concept and creative direction: Ahimanikya Satapathy',80,153);ctx.restore();
 }
 if(t>49.2){ctx.fillStyle=`rgba(34,29,23,${ease((t-49.2)/.8)})`;ctx.fillRect(0,0,W,H)}
}
await mkdir(path.join(base,'proof'),{recursive:true});
const proofs=[0,8.46,12.25,13.2,14.5,16,24.5,25.5,26.1,27.1,28.1,29.1,30.1,31.1,32.8,36.6,37.3,38.2,39,40.5,41.7,42.5,47];
for(const t of proofs){render(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'))}
const audit={stanceSamples:[],pickupSamples:[]};
for(let i=0;i<FPS*DURATION;i++){let t=i/FPS;if(t>=25.5&&t<=32.5){for(let leg=0;leg<4;leg++){const foot=footAt(t,leg);audit.stanceSamples.push({t,leg,...foot})}}if(t>=36.6&&t<38.5)audit.pickupSamples.push({t,...pickup(t)})}
await writeFile(path.join(base,'motion-contact-audit-v2.json'),JSON.stringify(audit,null,2)+'\n');
if(process.argv.includes('--proof-only')){console.log('Saved '+proofs.length+' frame proofs and motion audit.');process.exit(0)}
const start=process.argv.includes('--walk-test')?24:0,duration=process.argv.includes('--walk-test')?10:DURATION;
const output=process.argv.includes('--walk-test')?'walking-test-v2.mp4':'around-the-stone-revised-cut-v2.mp4';
const ff=spawn(process.env.CHIKU_FFMPEG||'ffmpeg',['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-ss',String(start),'-i',path.join(base,'sound-v2.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(duration),path.join(base,output)],{stdio:['pipe','inherit','inherit']});
const complete=once(ff,'close');
for(let i=0;i<FPS*duration;i++){render(start+i/FPS);const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain');if(i%(FPS*10)===0)console.log('Rendered '+i/FPS+' seconds')}
ff.stdin.end();const [code]=await complete;if(code!==0)throw Error('Encode failed '+code);
console.log('Rendered '+duration+' seconds to '+output);
