export const clamp=x=>Math.max(0,Math.min(1,x));
export const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
export const mix=(a,b,w)=>a.map((v,i)=>v+(b[i]-v)*w);
export const pulse=(t,a,b,c,d)=>ease((t-a)/(b-a))*(1-ease((t-c)/(d-c)));
export const aPoint=p=>[500+(p[0]-420)*.70,375+(p[1]-290)*.70];
export const sPoint=p=>[1060+(p[0]-350)*.73,340+(p[1]-240)*.73];
export function stateAt(t){
 const cup=pulse(t,.4,2,13.2,16),tell=pulse(t,16,17.5,21,23),question=pulse(t,21,22,25.3,27.8),pour=pulse(t,41,43,49.8,51.4);
 const sShoulders=[[160,450],[580,450]].map(sPoint),aShoulders=[[203,470],[620,470]].map(aPoint);
 sShoulders[0]=mix(sShoulders[0],[936,480],pour);
 let sElbows=[[937,555],[1215,560]],sHands=[[999,684],[1165,680]];
 const beat=Math.sin(t*.8)*3*cup;
 sHands[0]=mix(sHands[0],[1020+beat,575],cup);sHands[1]=mix(sHands[1],[1115+beat,575],cup);
 sElbows[0]=mix(sElbows[0],[939,545],cup);sElbows[1]=mix(sElbows[1],[1205,545],cup);
 sHands[0]=mix(sHands[0],[965,541],tell);
 sElbows[0]=mix(sElbows[0],[913,545],tell);
 // One smooth outward arc and wrist angle suggest pouring; there is no vessel prop.
 const tilt=pulse(t,44,46.2,48.2,50.3),pourHand=[967+30*tilt,563+31*tilt];
 sHands[0]=mix(sHands[0],pourHand,pour);sElbows[0]=mix(sElbows[0],[904,542],pour);
 const aElbows=[[382,565],mix([656,566],[674,563],question)],aHands=[[449,699],mix([609,694],[709,610],question)];
 return{t,cup,tell,question,pour,tilt,aShoulders,sShoulders,aElbows,aHands,sElbows,sHands,headA:-.055*question+(t>51.5?.018:0),headS:-.035*pulse(t,27,29,32,34)};
}
export function faceAt(t,who){const times=who==='a'?[3.3,10.7,18.2,25.7,32.4,40.5,48.5,55.8]:[5.4,12.8,20.9,26.3,34.7,41.2,50.9,57.1];const blink=times.some(x=>t>=x&&t<x+4/24);let pose=who==='a'?(t>=32?2:t>=21?1:0):(t>=34?2:t>=26?1:0);return{blink,pose:blink?3:pose};}
