from pathlib import Path
import json
p=Path(__file__).parent
plan=json.loads((p/'timing-plan-v1.json').read_text())
cues=[{'start':c['start'],'end':c['end'],'or':c['speaker']['or']+': '+c['text']['or'],'en':c['speaker']['en']+': '+c['text']['en'],'type':'written-dialogue'} for c in plan['timingPlan']]
sounds=[(0,1.5,'[ପତ୍ରର ହାଲୁକା ଶବ୍ଦ]','[Leaves rustle softly]'),(14,16,'[କପଡ଼ାର ହାଲୁକା ଘଷା]','[A soft rustle of clothing]'),(27,29.5,'[ପତ୍ରର ହାଲୁକା ଶବ୍ଦ]','[Leaves rustle softly]'),(39.5,41.5,'[କପଡ଼ାର ହାଲୁକା ଘଷା]','[A soft rustle of clothing]'),(56.7,57.8,'[ପତ୍ରର ହାଲୁକା ଶବ୍ଦ]','[Leaves rustle softly]')]
cues+= [{'start':a,'end':b,'or':o,'en':e,'type':'sound-description'} for a,b,o,e in sounds]
cues.sort(key=lambda c:c['start'])
assert all(a['end']<=b['start'] for a,b in zip(cues,cues[1:]))
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d}.{ms%1000:03d}'
for lang in ['or','en']:
 text='WEBVTT\n\n'+''.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c[lang]}\n\n' for i,c in enumerate(cues))
 (p/f'captions-{lang}-v1.vtt').write_text(text.rstrip()+'\n')
(p/'caption-cues-v1.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2)+'\n')
print(f'{len(cues)} paired cues; six canonical dialogue lines.')
