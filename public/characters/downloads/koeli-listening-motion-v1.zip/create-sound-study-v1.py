"""Original synthesized motion-study effects; no speech or field recording."""
import json,wave
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent
rate=48000; duration=8; n=rate*duration
rng=np.random.default_rng(50817)
noise=rng.standard_normal(n)
wind=np.convolve(noise,np.ones(96)/96,mode='same')
t=np.arange(n)/rate
bed=.010*wind*(.55+.2*np.sin(t*1.7))
fade=np.minimum(np.minimum(t/.3,(duration-t)/.4),1).clip(0,1)
left=bed.copy();right=np.roll(bed,53)*.94
for at in [3.25,6.25]:
 length=round(.22*rate);tt=np.arange(length)/rate
 local=rng.standard_normal(length)
 burst=local-np.convolve(local,np.ones(14)/14,mode='same')
 envelope=(1-np.exp(-tt/.0007))*np.exp(-tt/.014)
 soft_tone=np.sin(2*np.pi*(740*tt-620*tt*tt))*np.exp(-tt/.035)
 sound=.065*burst*envelope+.045*soft_tone
 start=round(at*rate);left[start:start+length]+=.82*sound;right[start:start+length]+=sound
stereo=np.stack([left*fade,right*fade],axis=1)
peak=float(np.abs(stereo).max());assert 0<peak<.8
with wave.open(str(p/'sound-study-v1.wav'),'wb') as f:
 f.setnchannels(2);f.setsampwidth(2);f.setframerate(rate);f.writeframes((stereo*32767).astype('<i2').tobytes())
report={'type':'Original synthesized sound-design sketch','speech':False,'fieldRecording':False,'music':False,'sampleRate':rate,'channels':2,'duration':duration,'dropTimes':[3.25,6.25],'peakDbFS':round(20*np.log10(peak),2),'rmsDbFS':round(20*np.log10(np.sqrt(np.mean(stereo**2))),2),'note':'Soft filtered-noise bed with short damped tap effects. Final sound design remains open.'}
(p/'sound-study-review-v1.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
