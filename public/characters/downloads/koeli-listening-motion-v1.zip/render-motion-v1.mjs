import {createRequire} from 'node:module';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
const require=createRequire(import.meta.url);
const {createCanvas,loadImage}=require(process.env.KOELI_CANVAS_MODULE || '@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url));
const [bg,rig]=await Promise.all([loadImage(path.join(base,'background-v1.png')),loadImage(path.join(base,'rig-v2.png'))]);
const W=1536,H=1024,FPS=24,DURATION=8;
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d');
const rects={body:[0,0,710,810],head:[740,200,500,450],leaf:[0,810,720,444],drop:[900,810,350,444]};
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
const impacts=[3.25,6.25];
function piece(name,px,py,sx,sy,scale,angle=0){const [x,y,w,h]=rects[name];ctx.save();ctx.translate(px,py);ctx.rotate(angle);ctx.scale(scale,scale);ctx.drawImage(rig,x,y,w,h,x-sx,y-sy,w,h);ctx.restore()}
function draw(t){
 ctx.clearRect(0,0,W,H);ctx.drawImage(bg,0,0,W,H);
 const attention=smooth((t-1.15)/1.05)*(1-.35*smooth((t-6.8)/.9));
 const headAngle=.19*attention;
 piece('body',30,160,0,0,1);
 piece('head',615,300,1010,460,.70,headAngle);
 let leafAngle=0;
 for(const at of impacts){const d=t-at;if(d>=0&&d<1.4)leafAngle-=.048*Math.exp(-3*d)*Math.sin(12*d)}
 piece('leaf',1440,575,620,900,.80,leafAngle);
 for(const at of impacts){
  const travel=.72,start=at-travel;
  if(t>=start&&t<at){const p=(t-start)/travel;const y=222+(630-222)*p*p;piece('drop',1100,y,1008,1000,.12)}
  const d=t-at;
  if(d>=0&&d<.55){
   ctx.save();ctx.globalAlpha=(1-d/.55)*.65;ctx.strokeStyle='#e5eff0';ctx.lineWidth=2;
   ctx.beginPath();ctx.ellipse(1100,630+Math.sin(d*12)*3,6+d*48,2+d*9,-.19,0,Math.PI*2);ctx.stroke();
   ctx.restore();
  }
 }
}
await mkdir(path.join(base,'proof'),{recursive:true});
for(const t of [0,2.4,3.24,3.38,6.4,7.8]){draw(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'))}
if(process.argv.includes('--proof-only')){console.log('Saved six motion frame proofs.');process.exit(0)}
const ffmpeg=process.env.KOELI_FFMPEG || 'ffmpeg';
const out=path.join(base,'koeli-listening-motion-v1.mp4');
const ff=spawn(ffmpeg,['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-i',path.join(base,'sound-study-v1.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(DURATION),out],{stdio:['pipe','inherit','inherit']});
const completion=once(ff,'close');
for(let i=0;i<FPS*DURATION;i++){draw(i/FPS);const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain')}
ff.stdin.end();const [code]=await completion;if(code!==0)throw Error('Video encode failed '+code);
console.log(`Rendered ${FPS*DURATION} frames / ${DURATION}s: ${out}`);
