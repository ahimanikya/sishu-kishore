from pathlib import Path
import json,wave
import numpy as np
p=Path(__file__).parent;sr=48000;duration=56;n=sr*duration;rng=np.random.default_rng(180318)
t=np.arange(n)/sr
white=rng.normal(0,1,n);water=np.convolve(white,np.ones(120)/120,mode='same')
water*=.035*(.7+.2*np.sin(2*np.pi*.17*t)+.1*np.sin(2*np.pi*.41*t))
audio=water.copy()
events=[(.8,.8,'cloth'),(2.7,1,'lift'),(4.4,.9,'cloth'),(12.3,.6,'cloth'),(25.5,.9,'shift'),(27.1,.9,'shift'),(31.6,1.2,'cloth'),(34.3,.5,'parcel'),(35.1,.6,'cloth'),(39.6,.6,'cloth'),(42.6,.7,'seat')]
for start,length,kind in events:
 count=int(length*sr);u=np.arange(count)/sr;env=np.sin(np.pi*np.arange(count)/max(1,count-1))**2
 noise=rng.normal(0,1,count);rustle=np.convolve(noise,np.ones(12)/12,mode='same')*.035*env
 if kind=='parcel':rustle+=.05*np.sin(2*np.pi*115*u)*np.exp(-u*18)
 if kind=='seat':rustle+=.012*np.sin(2*np.pi*(130*u+12*u*u))*env
 a=int(start*sr);audio[a:a+count]+=rustle
for start in [9.5,23.8,47.5,51.7]:
 count=int(.15*sr);u=np.arange(count)/sr;knock=.006*np.sin(2*np.pi*420*u)*np.exp(-u*45);a=int(start*sr);audio[a:a+count]+=knock
fade=np.minimum(1,np.minimum(t/.35,(duration-t)/.8));audio*=np.maximum(0,fade)
peak=float(np.max(np.abs(audio)));audio*=10**(-20/20)/peak
stereo=np.column_stack((audio,audio*.98));pcm=np.int16(np.clip(stereo,-1,1)*32767)
with wave.open(str(p/'sound-draft-v1.wav'),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes(pcm.tobytes())
review={'duration':duration,'sampleRate':sr,'channels':2,'peakDbFS':float(20*np.log10(np.max(np.abs(stereo)))),'rmsDbFS':float(20*np.log10(np.sqrt(np.mean(stereo**2)))),'clippedSamples':int(np.sum(np.abs(stereo)>=1)),'events':[{'time':a,'duration':b,'kind':k} for a,b,k in events],'provenance':'Original deterministic synthesized water, cloth, soft parcel/seat contact and distant taps. No human voices, music, field recordings or external samples.'}
(p/'sound-review-v1.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review,indent=2))
