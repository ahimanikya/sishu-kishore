import {shouldersAt} from './body-poses-v1.mjs';
export const clamp=x=>Math.max(0,Math.min(1,x));
export const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
export const mix=(a,b,p)=>a.map((x,i)=>x+(b[i]-x)*p);
export const pulse=(t,a,b,c,d)=>ease((t-a)/(b-a))*(1-ease((t-c)/(d-c)));
const rot=(p,a)=>[p[0]*Math.cos(a)-p[1]*Math.sin(a),p[0]*Math.sin(a)+p[1]*Math.cos(a)];
export function stateAt(t){
 const pickup=pulse(t,.5,2.4,3.0,5.8),putdown=pulse(t,31,33.4,34.5,37.2),bend=Math.max(pickup,putdown),sit=ease((t-39)/3.6);
 const held=t>=2.7&&t<34.3;
 const start=[890,805],carry=[1050,566];
 const parcel=t<2.7?start:t<5.8?mix(start,carry,ease((t-2.7)/3.1)):t<31?carry:t<34.3?mix(carry,start,ease((t-31)/3.3)):start;
 const shift=ease((t-25.4)/3.0),mLift=Math.sin(Math.PI*shift)*4;
 const r={bend,sit,hip:[1050-90*sit,439.8+220*bend+175*sit],angle:.75*bend-.12*pulse(t,38,39.5,41.5,43),scale:.58};
 const s={t,r,parcel,held,pickup,putdown,sit,shift,mLift};
 const rs=shouldersAt(s),ms=[malatiPoint([250,162],s),malatiPoint([486,160],s)];
 let rh=rs.map((p,i)=>[p[0]+(i?-20:20),p[1]+235]);
 const grip=[[parcel[0]-76,parcel[1]-27],[parcel[0]+76,parcel[1]-27]];
 const contact=pulse(t,1.5,2.7,34.3,35.4);rh=rh.map((p,i)=>mix(p,grip[i],contact));
 const lap=rs.map((p,i)=>[p[0]+(i?-25:25),p[1]+210]);rh=rh.map((p,i)=>mix(p,lap[i],ease((t-38)/4.8)));
 let mh=[[malatiPoint([520,510],s)[0],malatiPoint([520,510],s)[1]],malatiPoint([630,565],s)];
 const call=0;mh[1]=mix(mh[1],[840,455],call);
 const invite=pulse(t,26,27.2,30,32);mh[1]=mix(mh[1],[ms[1][0]+85,616],invite);
 return {...s,rs,ms,rh,mh,grip,contact};
}
export function raghuPoint(p,s){
 const scale=.58,baseHip=[1050,439.8],v=[(p[0]-400)*scale,(p[1]-360)*scale];
 if(p[1]<=360){const q=rot(v,s.r.angle);return[s.r.hip[0]+q[0],s.r.hip[1]+q[1]];}
 const y=p[1],top=Math.pow(1-clamp((y-360)/510),1.1),knee=Math.sin(Math.PI*clamp((y-360)/510));
 return[baseHip[0]+v[0]+(s.r.hip[0]-baseHip[0])*top+(p[0]-400)*.22*s.r.sit*knee,
 baseHip[1]+v[1]+(s.r.hip[1]-baseHip[1])*top];
}
export function malatiPoint(p,s){
 const scale=.43,base=[680,615],bodyShift=-60*s.shift,basePoint=[base[0]+(p[0]-360)*scale+bodyShift,base[1]+(p[1]-545)*scale-s.mLift];
 if(p[1]<800)return basePoint;
 const near=ease((s.t-25.3)/1.2),far=ease((s.t-27.0)/1.2),w=ease((p[0]-505)/65),progress=near*(1-w)+far*w;
 const legWeight=ease((p[1]-800)/100),lift=(Math.sin(Math.PI*near)*(1-w)+Math.sin(Math.PI*far)*w)*8;
 return[basePoint[0]+(-60*progress-bodyShift)*legWeight,basePoint[1]+(s.mLift-lift)*legWeight];
}
export function faceAt(t,who){
 const starts=who==='r'?[6.5,11.7,18,24.2,30,38.2,46.8,52.5]:[3.8,10.4,16,23,30.6,36.6,44.5,50.8,54.9];
 const blink=starts.some(a=>t>=a&&t<a+4/24);
 return {pose:blink?3:t>(who==='r'?44:43)?2:who==='r'&&(t<12||t>31&&t<37.2)?1:0,blink};
}
