import {createRequire} from 'node:module';
import {writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {stateAt,clothPoint,ease,mix} from './motion-v1.mjs';
import {drawPart,bone,lowerBody,armsAt} from './puppet-v1.mjs';
const require=createRequire(import.meta.url);
const {createCanvas,loadImage,GlobalFonts}=require(process.env.NILU_CANVAS_MODULE||'@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url));
const [bg,chaiti,nilu,cloth,cbody,nbody,weaver,armatlas]=await Promise.all(['background-v1.png','chaiti-rig-v1.png','nilu-rig-v1.png','cloth-v1.png','chaiti-body-rig-v1.png','nilu-body-rig-v1.png','weaver-rig-v1.png','arms-v2.png'].map(x=>loadImage(path.join(base,x))));
GlobalFonts.registerFromPath(path.join(base,'baloo-bhaina-2.ttf'),'Baloo Bhaina 2');
const W=1536,H=1024,FPS=24,DURATION=54;
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d');
const piece=(...args)=>drawPart(ctx,...args);
function triangle(src,dst){
 const [a,b,c]=src,[A,B,C]=dst,den=(b[0]-a[0])*(c[1]-a[1])-(c[0]-a[0])*(b[1]-a[1]);
 const x1=b[0]-a[0],y1=b[1]-a[1],x2=c[0]-a[0],y2=c[1]-a[1];
 const xx=((B[0]-A[0])*y2-(C[0]-A[0])*y1)/den,xy=(-(B[0]-A[0])*x2+(C[0]-A[0])*x1)/den;
 const yx=((B[1]-A[1])*y2-(C[1]-A[1])*y1)/den,yy=(-(B[1]-A[1])*x2+(C[1]-A[1])*x1)/den;
 ctx.save();ctx.beginPath();const mid=[(A[0]+B[0]+C[0])/3,(A[1]+B[1]+C[1])/3];const expand=p=>{const d=Math.hypot(p[0]-mid[0],p[1]-mid[1]);return p.map((x,i)=>x+(x-mid[i])*.65/d)};ctx.moveTo(...expand(A));ctx.lineTo(...expand(B));ctx.lineTo(...expand(C));ctx.closePath();ctx.clip();ctx.transform(xx,yx,xy,yy,A[0]-xx*a[0]-xy*a[1],A[1]-yx*a[0]-yy*a[1]);ctx.drawImage(cloth,0,0);ctx.restore();
}
function fabric(s){
 const nx=28,ny=8,source=(u,v)=>[52+1433*u,51+923*v];
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
  const uv=[[i/nx,j/ny],[(i+1)/nx,j/ny],[(i+1)/nx,(j+1)/ny],[i/nx,(j+1)/ny]];
  const src=uv.map(x=>source(...x)),dst=uv.map(x=>clothPoint(...x,s));
  triangle([src[0],src[1],src[2]],[dst[0],dst[1],dst[2]]);triangle([src[0],src[2],src[3]],[dst[0],dst[2],dst[3]]);
 }
}
function backgroundAction(t){
 const p=ease((t-.6)/3.4),rest=ease((t-4.2)/1.4);
 piece(weaver,[20,20,750,950],[400,940],[785,626],.30);
 piece(weaver,[1140,650,380,310],[1320,920],[946,634],.28);
 const left=mix(mix([810,535],[823,585],p),[784,550],rest),right=mix(mix([912,538],[925,588],p),[854,550],rest);
 bone(ctx,weaver,[1110,200,420,380],[1210,300],[1460,510],[841,476],right,.30);
 bone(ctx,weaver,[760,200,395,390],[845,300],[1100,530],[731,470],left,.30);
 const clothAt=mix([861,543],[874,593],p);
 piece(weaver,[760,680,380,250],[950,820],clothAt,.28,-.05*(1-p));
}
function draw(t){
 const s=stateAt(t);ctx.clearRect(0,0,W,H);ctx.drawImage(bg,0,0,W,H);backgroundAction(t);
 ctx.fillStyle='rgba(70,43,22,.13)';for(const f of [...s.cfeet,...s.nfeet]){ctx.beginPath();ctx.ellipse(f[0],f[1]+3,34,8,0,0,Math.PI*2);ctx.fill();}
 const clegs=lowerBody(ctx,cbody,'chaiti',s.croot,s.cfeet),nlegs=lowerBody(ctx,nbody,'nilu',s.nroot,s.nfeet);
 piece(cbody,[100,40,510,610],[350,115],s.croot,.38);
 piece(nbody,[0,100,620,520],[300,175],s.nroot,.38);
 const tired=s.tired>.55&&s.straight<.5;
 piece(chaiti,tired?[1035,30,495,440]:[485,30,500,440],tired?[1272,435]:[747,435],[s.croot[0],s.croot[1]+7],.48,s.cHeadAngle);
 const notice=s.notice>.55&&s.straight<.5;
 piece(nilu,notice?[1060,50,470,460]:[585,50,455,460],notice?[1308,478]:[830,478],[s.nroot[0],s.nroot[1]+6],.45,s.nHeadAngle);
 fabric(s);const arms=armsAt(ctx,{c:chaiti,n:nilu,a:armatlas},s);
 const sleeve=(img,anchor,at,poly)=>{ctx.save();ctx.translate(...at);ctx.scale(.38,.38);ctx.beginPath();poly.forEach((p,i)=>i?ctx.lineTo(p[0]-anchor[0],p[1]-anchor[1]):ctx.moveTo(p[0]-anchor[0],p[1]-anchor[1]));ctx.closePath();ctx.clip();ctx.drawImage(img,-anchor[0],-anchor[1]);ctx.restore();};
 sleeve(cbody,[350,115],s.croot,[[250,90],[295,130],[280,200],[250,255],[165,245],[130,185],[190,120]]);
 sleeve(cbody,[350,115],s.croot,[[460,80],[525,110],[565,175],[540,225],[500,250],[470,200]]);
 sleeve(nbody,[300,175],s.nroot,[[450,200],[550,255],[605,305],[585,360],[510,405],[465,370],[440,290]]);
 sleeve(nbody,[300,175],s.nroot,[[140,185],[200,240],[145,390],[70,360],[25,300],[50,250]]);
 ctx.save();ctx.fillStyle='rgba(250,246,232,.94)';ctx.fillRect(0,925,W,99);ctx.fillStyle='#273c35';ctx.font='30px "Baloo Bhaina 2"';ctx.fillText('ଏ ପଟଟା ଧର · ଚଳଚ୍ଚିତ୍ରର ପ୍ରଥମ ଖସଡ଼ା',42,964);ctx.font='22px sans-serif';ctx.fillText('Hold This End · Animation draft',42,997);ctx.textAlign='right';ctx.font='21px sans-serif';ctx.fillText('Concept and creative direction: Ahimanikya Satapathy',1494,966);ctx.font='22px "Baloo Bhaina 2"';ctx.fillText('ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା: Ahimanikya Satapathy',1494,998);ctx.restore();
 return {t,phase:s.phase,roots:[s.croot,s.nroot],feet:[s.cfeet,s.nfeet],steps:[s.cstep,s.nstep],legs:[clegs,nlegs],arms,corners:s.corners,held:s.held};
}
await mkdir(path.join(base,'proof'),{recursive:true});
for(const t of [0,3,18,23,28,29.3,30.8,31.5,32.8,34,35.5,36.5,38.5,40,41.5,43.4,44.5,48,50.5,53.5]){draw(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'));}
if(process.argv.includes('--proof-only')){console.log('Twenty proof frames saved.');process.exit(0);}
const ff=spawn(process.env.NILU_FFMPEG||'ffmpeg',['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-i',path.join(base,'sound-draft-v1.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(DURATION),path.join(base,'hold-this-end-first-cut-v1.mp4')],{stdio:['pipe','inherit','inherit']});
const completion=once(ff,'close'),audit=[];
for(let i=0;i<FPS*DURATION;i++){audit.push(draw(i/FPS));const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain');if(i%240===0)console.log(`${i}/${FPS*DURATION}`);}
ff.stdin.end();const [code]=await completion;if(code)throw Error('Encode failed '+code);
await writeFile(path.join(base,'contact-audit-v1.json'),JSON.stringify({frames:audit,notes:'Continuous cutout animation draft. Provisional dialogue timing; voices and mouth performance pending.'},null,2)+'\n');
console.log(`Rendered ${FPS*DURATION} frames / ${DURATION} seconds.`);
