export const clamp=x=>Math.max(0,Math.min(1,x));
export const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
export const lerp=(a,b,p)=>a+(b-a)*p;
export const mix=(a,b,p)=>a.map((x,i)=>lerp(x,b[i],p));
export function stepState(t,who){
 const delta=who==='chaiti'?260:-170;
 const initial=who==='chaiti'?[[409,755],[493,732]]:[[1203,805],[1033,785]];
 const progress=[0,0],lift=[0,0];
 for(let i=0;i<4;i++){const p=clamp((t-(31+i*1.15))/1.05),leg=i%2;progress[leg]+=p*.5;if(p>0&&p<1)lift[leg]=22*Math.sin(Math.PI*p);}
 const feet=initial.map((p,i)=>[p[0]+delta*progress[i],p[1]+delta*.078*progress[i]-lift[i]]);
 return {feet,shift:delta*(progress[0]+progress[1])/2,lift,progress};
}
export function stateAt(t){
 const cstep=stepState(t,'chaiti'),nstep=stepState(t,'nilu');
 const tired=ease((t-15)/4),notice=ease((t-22.4)/1.5),rise=ease((t-28)/2.7);
 const gather=ease((t-35.5)/3),lower=ease((t-40)/3.4),release=ease((t-43.4)/1),straight=ease((t-49)/1.3);
 const croot=[440+cstep.shift+40*lower,360+cstep.shift*.078+180*lower];
 const nroot=[1120+nstep.shift+10*lower,545-165*rise+nstep.shift*.078+193*lower+30*straight];
 const shoulders=[
  [croot[0]+62,croot[1]+26],[croot[0]-55,croot[1]+30],
  [nroot[0]-74,nroot[1]+45],[nroot[0]+77,nroot[1]+57]
 ];
 const fidget=(1-notice)*Math.sin(t*2.5)*2.5;
 let hands=[
  [croot[0]+202,croot[1]+64+23*tired],
  [croot[0]+92,croot[1]+78+24*tired],
  [nroot[0]-199+fidget,nroot[1]+84],
  [nroot[0]-49-fidget,nroot[1]+108]
 ];
 const meeting=[[815,445],[850,485],[823,449],[858,489]];
 const placed=[[800,700],[860,740],[808,704],[868,744]];
 hands=hands.map((p,i)=>mix(mix(p,meeting[i],gather),placed[i],lower));
 const heldCorners=[hands[0],hands[2],hands[3],hands[1]].map(p=>[...p]);
 if(t>=43.4){
  const rest=[[830,720],[785,770],[930,690],[950,755]];
  hands=hands.map((p,i)=>mix(p,rest[i],release));
 }
 const corners=t>=43.4?[placed[0],mix(placed[2],[801,701],straight),mix(placed[3],[861,741],straight),placed[1]]:heldCorners;
 const touch=ease((t-48)/.7)*(1-ease((t-51)/.6));if(t>=48){hands[1]=mix(hands[1],corners[3],touch);hands[2]=mix(hands[2],corners[1],touch);}
 return {t,croot,nroot,cfeet:cstep.feet,nfeet:nstep.feet,cstep,nstep,shoulders,hands,corners,tired,notice,rise,gather,lower,release,straight,
  cHeadAngle:-.015+.04*tired+.15*lower-.14*straight,nHeadAngle:-.04+.26*notice-.36*lower+.20*straight,
  phase:t<12?'measuring':t<26?'waiting':t<31?'rising':t<35.5?'stepping':t<40?'folding':t<43.4?'placing':t<48?'exchange':'straightening',held:t<43.4};
}
export function clothPoint(u,v,s){
 const [a,b,c,d]=s.corners;
 const top=mix(a,b,u),bottom=mix(d,c,u);let p=mix(top,bottom,v);
 const sag=(lerp(70+100*v+8*s.tired,185,s.gather))*Math.sin(Math.PI*u);
 p[1]+=sag;p[1]+=Math.sin(Math.PI*u)*Math.sin(Math.PI*v)*Math.sin(u*12-s.t*1.6)*2*(1-s.gather);
 const end=mix(mix(s.corners[0],s.corners[1],u),mix(s.corners[3],s.corners[2],u),v);
 const reach=Math.sin(Math.PI*u);const flat=[end[0]-60*reach,end[1]+75*reach];
 return mix(p,flat,s.lower);
}
