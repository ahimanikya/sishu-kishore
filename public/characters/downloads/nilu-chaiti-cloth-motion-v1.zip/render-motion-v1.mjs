import {createRequire} from 'node:module';
import {writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
const require=createRequire(import.meta.url);
const {createCanvas,loadImage,GlobalFonts}=require(process.env.NILU_CANVAS_MODULE||'@napi-rs/canvas');
const base=path.dirname(fileURLToPath(import.meta.url));
const [bg,chaiti,nilu,cloth]=await Promise.all(['background-v1.png','chaiti-rig-v1.png','nilu-rig-v1.png','cloth-v1.png'].map(x=>loadImage(path.join(base,x))));
GlobalFonts.registerFromPath(path.join(base,'baloo-bhaina-2.ttf'),'Baloo Bhaina 2');
const W=1536,H=1024,FPS=24,DURATION=8;
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d');
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
const mix=(a,b,p)=>a.map((x,i)=>x+(b[i]-x)*p);
const transform=(p,a,at,s,r)=>{const x=(p[0]-a[0])*s,y=(p[1]-a[1])*s;return [at[0]+x*Math.cos(r)-y*Math.sin(r),at[1]+x*Math.sin(r)+y*Math.cos(r)]};
function piece(img,rect,anchor,at,scale,angle=0,alpha=1){const [x,y,w,h]=rect;ctx.save();ctx.globalAlpha=alpha;ctx.translate(...at);ctx.rotate(angle);ctx.scale(scale,scale);ctx.drawImage(img,x,y,w,h,x-anchor[0],y-anchor[1],w,h);ctx.restore();}
function state(t){
 const tired=smooth((t-1.7)/1.8),notice=smooth((t-4.0)/1.0),recover=smooth((t-6.1)/1.2);
 const fidget=(1-notice)*Math.sin(t*3.3)*.022;
 const arms=[
  {id:'chaiti-far',img:chaiti,rect:[1040,530,490,340],handRect:[1390,670,125,100],anchor:[1120,610],at:[502,386],s:.40,r:.03+.17*tired-.035*recover,pinch:[1471,709]},
  {id:'chaiti-near',img:chaiti,rect:[535,520,465,340],handRect:[870,645,120,110],anchor:[615,600],at:[385,390],s:.44,r:.06+.16*tired-.03*recover,pinch:[950,688]},
  {id:'nilu-far',img:nilu,rect:[1080,580,450,325],handRect:[1080,730,160,120],anchor:[1420,675],at:[1046,594],s:.43,r:fidget*.6-.04*notice,pinch:[1128,774]},
  {id:'nilu-near',img:nilu,rect:[605,580,425,320],handRect:[605,730,160,120],anchor:[925,675],at:[1197,602],s:.46,r:fidget+.025*notice,pinch:[650,770]}
 ];
 for(const a of arms)a.grasp=transform(a.pinch,a.anchor,a.at,a.s,a.r);
 return {t,tired,notice,recover,arms,corners:[arms[0].grasp,arms[2].grasp,arms[3].grasp,arms[1].grasp],chaitiAngle:-.015+.045*tired-.025*recover,niluAngle:-.04+.26*notice};
}
function clothPoint(u,v,s){const [a,b,c,d]=s.corners;const top=mix(a,b,u),bottom=mix(d,c,u),p=mix(top,bottom,v);p[1]+=(70+100*v+8*s.tired)*Math.sin(Math.PI*u);p[1]+=Math.sin(Math.PI*u)*Math.sin(Math.PI*v)*Math.sin(u*12-s.t*1.6)*2;return p;}
function triangle(src,dst){
 const [a,b,c]=src,[A,B,C]=dst,den=(b[0]-a[0])*(c[1]-a[1])-(c[0]-a[0])*(b[1]-a[1]);
 const x1=b[0]-a[0],y1=b[1]-a[1],x2=c[0]-a[0],y2=c[1]-a[1];
 const xx=((B[0]-A[0])*y2-(C[0]-A[0])*y1)/den,xy=(-(B[0]-A[0])*x2+(C[0]-A[0])*x1)/den;
 const yx=((B[1]-A[1])*y2-(C[1]-A[1])*y1)/den,yy=(-(B[1]-A[1])*x2+(C[1]-A[1])*x1)/den;
 ctx.save();ctx.beginPath();const mid=[(A[0]+B[0]+C[0])/3,(A[1]+B[1]+C[1])/3];const expand=p=>{const d=Math.hypot(p[0]-mid[0],p[1]-mid[1]);return p.map((x,i)=>x+(x-mid[i])*.65/d)};ctx.moveTo(...expand(A));ctx.lineTo(...expand(B));ctx.lineTo(...expand(C));ctx.closePath();ctx.clip();ctx.transform(xx,yx,xy,yy,A[0]-xx*a[0]-xy*a[1],A[1]-yx*a[0]-yy*a[1]);ctx.drawImage(cloth,0,0);ctx.restore();
}
function fabric(s){
 const nx=28,ny=8,source=(u,v)=>[52+1433*u,51+923*v];
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
  const uv=[[i/nx,j/ny],[(i+1)/nx,j/ny],[(i+1)/nx,(j+1)/ny],[i/nx,(j+1)/ny]];
  const src=uv.map(x=>source(...x)),dst=uv.map(x=>clothPoint(...x,s));
  triangle([src[0],src[1],src[2]],[dst[0],dst[1],dst[2]]);triangle([src[0],src[2],src[3]],[dst[0],dst[2],dst[3]]);
 }
}
function draw(t){
 const s=state(t);ctx.clearRect(0,0,W,H);ctx.drawImage(bg,0,0,W,H);
 ctx.save();ctx.fillStyle='rgba(70,43,22,.12)';ctx.beginPath();ctx.ellipse(447,758,100,15,0,0,Math.PI*2);ctx.ellipse(1120,815,130,17,0,0,Math.PI*2);ctx.fill();ctx.restore();
 
 piece(chaiti,[65,110,405,890],[260,155],[440,360],.48);
 piece(nilu,[20,340,590,640],[324,390],[1120,545],.46);
 const cn=s.tired>.55?[1035,30,495,440]:[485,30,500,440];
 const ca=s.tired>.55?[1272,435]:[747,435];
 piece(chaiti,cn,ca,[440,367],.48,s.chaitiAngle);
 const nn=s.notice>.55?[1060,50,470,460]:[585,50,455,460],na=s.notice>.55?[1308,478]:[830,478];
 piece(nilu,nn,na,[1120,551],.45,s.niluAngle);
 fabric(s);
 for(const a of s.arms)piece(a.img,a.rect,a.anchor,a.at,a.s,a.r);
 for(const a of s.arms)piece(a.img,a.handRect,a.anchor,a.at,a.s,a.r);
 ctx.save();ctx.fillStyle='rgba(250,246,232,.94)';ctx.fillRect(0,925,W,99);ctx.fillStyle='#273c35';ctx.font='30px "Baloo Bhaina 2"';ctx.fillText('ଏ ପଟଟା ଧର · ଚଳନର ନମୁନା',42,964);ctx.font='22px sans-serif';ctx.fillText('Hold This End · Motion study',42,997);ctx.textAlign='right';ctx.font='21px sans-serif';ctx.fillText('Concept and creative direction: Ahimanikya Satapathy',1494,966);ctx.font='22px "Baloo Bhaina 2"';ctx.fillText('ପରିକଳ୍ପନା ଓ ସୃଜନ ନିର୍ଦ୍ଦେଶନା: Ahimanikya Satapathy',1494,998);ctx.restore();
 return s;
}
await mkdir(path.join(base,'proof'),{recursive:true});
for(const t of [0,1,2.6,3.9,4.5,5.4,6.5,7.9]){draw(t);await writeFile(path.join(base,'proof',`frame-${t.toFixed(2)}.png`),canvas.toBuffer('image/png'));}
const audit=[];for(let i=0;i<FPS*DURATION;i++){const s=state(i/FPS);audit.push({t:s.t,corners:s.corners,hands:s.arms.map(a=>({id:a.id,grasp:a.grasp,shoulder:a.at,angle:a.r})),feet:[[409,755],[493,732],[1033,785],[1203,805]],headAngles:[s.chaitiAngle,s.niluAngle],tired:s.tired,notice:s.notice});}
await writeFile(path.join(base,'contact-audit-v1.json'),JSON.stringify({frames:audit,notes:'Hand positions and cloth corners share the same transform; body and feet are fixed during this acting study.'},null,2)+'\n');
if(process.argv.includes('--proof-only')){console.log('Eight proof frames and contact audit saved.');process.exit(0);}
const ff=spawn(process.env.NILU_FFMPEG||'ffmpeg',['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-i',path.join(base,'sound-study-v1.wav'),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-t',String(DURATION),path.join(base,'hold-this-end-motion-v1.mp4')],{stdio:['pipe','inherit','inherit']});
const completion=once(ff,'close');for(let i=0;i<FPS*DURATION;i++){draw(i/FPS);const rgba=ctx.getImageData(0,0,W,H).data;if(!ff.stdin.write(Buffer.from(rgba.buffer)))await once(ff.stdin,'drain');}ff.stdin.end();const [code]=await completion;if(code)throw Error('Encode failed '+code);console.log(`Rendered ${FPS*DURATION} frames / ${DURATION} seconds.`);
