export function textureTriangle(ctx,img,src,dst){
 const[a,b,c]=src,[A,B,C]=dst,x1=b[0]-a[0],y1=b[1]-a[1],x2=c[0]-a[0],y2=c[1]-a[1],den=x1*y2-x2*y1;
 if(Math.abs(den)<.0001)return;
 const xx=((B[0]-A[0])*y2-(C[0]-A[0])*y1)/den,xy=(-(B[0]-A[0])*x2+(C[0]-A[0])*x1)/den,yx=((B[1]-A[1])*y2-(C[1]-A[1])*y1)/den,yy=(-(B[1]-A[1])*x2+(C[1]-A[1])*x1)/den;
 const mid=[(A[0]+B[0]+C[0])/3,(A[1]+B[1]+C[1])/3],expand=p=>{const d=Math.max(.001,Math.hypot(p[0]-mid[0],p[1]-mid[1]));return p.map((v,i)=>v+(v-mid[i])*.85/d)};
 ctx.save();ctx.beginPath();ctx.moveTo(...expand(A));ctx.lineTo(...expand(B));ctx.lineTo(...expand(C));ctx.closePath();ctx.clip();ctx.transform(xx,yx,xy,yy,A[0]-xx*a[0]-xy*a[1],A[1]-yx*a[0]-yy*a[1]);ctx.drawImage(img,0,0);ctx.restore();
}
export function mapBone(p,a,b,A,B,width){
 const dx=b[0]-a[0],dy=b[1]-a[1],sl=Math.hypot(dx,dy),tx=B[0]-A[0],ty=B[1]-A[1],tl=Math.hypot(tx,ty),u=((p[0]-a[0])*dx+(p[1]-a[1])*dy)/sl,v=(-(p[0]-a[0])*dy+(p[1]-a[1])*dx)/sl;
 return[A[0]+u/sl*tx-v*width*ty/tl,A[1]+u/sl*ty+v*width*tx/tl];
}
export function skinnedPoint(p,g,A,E,B){
 const d1=[g.e[0]-g.a[0],g.e[1]-g.a[1]],d2=[g.b[0]-g.e[0],g.b[1]-g.e[1]],l1=Math.hypot(...d1),l2=Math.hypot(...d2),axis=[d1[0]/l1+d2[0]/l2,d1[1]/l1+d2[1]/l2],l=Math.hypot(...axis);
 let w=Math.max(0,Math.min(1,(((p[0]-g.e[0])*axis[0]+(p[1]-g.e[1])*axis[1])/l+45)/90));w=w*w*(3-2*w);
 const upper=mapBone(p,g.a,g.e,A,E,g.width),fore=mapBone(p,g.e,g.b,E,B,g.width);
 return upper.map((v,i)=>v+(fore[i]-v)*w);
}
export function skinArm(ctx,img,g,A,E,B){
 const[x,y,w,h]=g.rect,nx=26,ny=18;
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
  const src=[[x+w*i/nx,y+h*j/ny],[x+w*(i+1)/nx,y+h*j/ny],[x+w*(i+1)/nx,y+h*(j+1)/ny],[x+w*i/nx,y+h*(j+1)/ny]],dst=src.map(p=>skinnedPoint(p,g,A,E,B));
  textureTriangle(ctx,img,[src[0],src[1],src[2]],[dst[0],dst[1],dst[2]]);textureTriangle(ctx,img,[src[0],src[2],src[3]],[dst[0],dst[2],dst[3]]);
 }
}
