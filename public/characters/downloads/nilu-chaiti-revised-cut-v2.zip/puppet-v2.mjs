import {skinArm,skinnedPoint} from './mesh-v2.mjs';
export function drawPart(ctx,img,rect,anchor,at,scale,angle=0){const [x,y,w,h]=rect;ctx.save();ctx.translate(...at);ctx.rotate(angle);ctx.scale(scale,scale);ctx.drawImage(img,x,y,w,h,x-anchor[0],y-anchor[1],w,h);ctx.restore();}
export function bone(ctx,img,rect,a,b,A,B,width,clip){const da=Math.atan2(b[1]-a[1],b[0]-a[0]),db=Math.atan2(B[1]-A[1],B[0]-A[0]),l=Math.hypot(B[0]-A[0],B[1]-A[1])/Math.hypot(b[0]-a[0],b[1]-a[1]);const [x,y,w,h]=rect;ctx.save();ctx.translate(...A);ctx.rotate(db);ctx.scale(l,width);ctx.rotate(-da);if(clip){ctx.beginPath();clip.forEach((p,i)=>i?ctx.lineTo(p[0]-a[0],p[1]-a[1]):ctx.moveTo(p[0]-a[0],p[1]-a[1]));ctx.closePath();ctx.clip();}ctx.drawImage(img,x,y,w,h,x-a[0],y-a[1],w,h);ctx.restore();}
export function knee(A,B,l1,l2,sign){const dx=B[0]-A[0],dy=B[1]-A[1],d=Math.max(.001,Math.hypot(dx,dy)),a=(l1*l1-l2*l2+d*d)/(2*d),h=Math.sqrt(Math.max(0,l1*l1-a*a));return [A[0]+dx*a/d-sign*dy*h/d,A[1]+dy*a/d+sign*dx*h/d];}
const legs={
 chaiti:[
  {thigh:[730,40,300,475],ta:[885,100],tb:[880,455],shin:[765,510,255,465],sa:[895,560],sb:[884,915],foot:[90,715,240,280],fa:[210,965],joint:[190,800],fs:.32,hip:[-20,118],sign:1},
  {thigh:[1160,40,330,475],ta:[1310,100],tb:[1320,455],shin:[1200,510,230,450],sa:[1320,560],sb:[1302,910],foot:[420,715,270,220],fa:[590,907],joint:[500,780],fs:.30,hip:[25,110],sign:-1}
 ],
 nilu:[
  {thigh:[680,55,320,455],ta:[850,125],tb:[835,455],shin:[700,510,270,430],sa:[820,565],sb:[870,880],foot:[20,700,290,250],fa:[195,930],joint:[210,805],fs:.32,hip:[30,140],sign:-1},
  {thigh:[1140,55,350,455],ta:[1310,125],tb:[1340,455],shin:[1200,510,285,430],sa:[1330,565],sb:[1355,885],foot:[375,735,235,200],fa:[485,918],joint:[515,800],fs:.30,hip:[-35,130],sign:1}
 ]
};
export function lowerBody(ctx,img,who,root,feet,lower=0){const audit=[];for(const i of [1,0]){const g=legs[who][i],A=[root[0]+g.hip[0],root[1]+g.hip[1]],B=[feet[i][0]+(g.joint[0]-g.fa[0])*g.fs,feet[i][1]+(g.joint[1]-g.fa[1])*g.fs],length=who==='chaiti'?118:130,K=knee(A,B,length,length,g.sign);if(who==='chaiti'&&i===1){const other=knee(A,B,length,length,1);K[0]+=(other[0]-K[0])*lower;K[1]+=(other[1]-K[1])*lower;}bone(ctx,img,g.shin,g.sa,g.sb,K,B,.32);bone(ctx,img,g.thigh,g.ta,g.tb,A,K,.32);drawPart(ctx,img,g.foot,g.fa,feet[i],g.fs);audit.push({leg:i,hip:A,knee:K,ankle:B,foot:feet[i],length,reach:Math.hypot(B[0]-A[0],B[1]-A[1])});}return audit;}
const arms=[
 {who:'c',rect:[1040,530,490,340],a:[1120,610],e:[1200,810],b:[1471,709],l1:85,l2:110,width:.40,sign:1},
 {who:'c',rect:[535,520,465,340],a:[615,600],e:[686,780],b:[950,688],l1:100,l2:125,width:.44,sign:1},
 {who:'n',rect:[1080,580,450,325],a:[1420,675],e:[1460,840],b:[1128,774],l1:85,l2:110,width:.43,sign:-1},
 {who:'n',rect:[605,580,425,320],a:[925,675],e:[970,840],b:[650,770],l1:95,l2:130,width:.46,sign:-1}
];
export function armsAt(ctx,imgs,s){const audit=[];for(let i=0;i<4;i++){const g=arms[i],A=s.shoulders[i],B=s.hands[i],E=knee(A,B,g.l1,g.l2,g.sign);if(i===0){const other=knee(A,B,g.l1,g.l2,-g.sign);E[0]+=(other[0]-E[0])*s.lower;E[1]+=(other[1]-E[1])*s.lower;}skinArm(ctx,imgs[g.who],g,A,E,B);audit.push({hand:i,shoulder:A,elbow:E,grasp:B,renderedGrasp:skinnedPoint(g.b,g,A,E,B),reach:Math.hypot(B[0]-A[0],B[1]-A[1]),maxReach:g.l1+g.l2});}return audit;}
