"""Deterministic synthesized cloth sounds; no voices, music or field samples."""
from pathlib import Path
import json,wave
import numpy as np
root=Path(__file__).resolve().parent
rate=48000;duration=54;n=rate*duration
rng=np.random.default_rng(318);audio=np.zeros((n,2))
events=[(.6,1.5,.45,0),(3.5,.6,.5,0),(7.1,.8,.4,.2),(12.4,.8,.45,.2),(16,1.5,.6,-.3),(28.3,1.2,.5,.3),(31,.65,.45,-.3),(32.15,.65,.45,.3),(33.3,.65,.45,-.3),(34.45,.65,.45,.3),(35.8,2.1,.6,0),(40.4,2.7,.75,0),(43.15,.6,.5,0),(49,.9,.5,0)]
for at,length,gain,pan in events:
 size=int(length*rate);t=np.arange(size)/rate
 noise=rng.normal(0,1,size)
 low=np.convolve(noise,np.ones(17)/17,mode='same')
 slow=np.convolve(noise,np.ones(401)/401,mode='same')
 envelope=np.sin(np.pi*t/length)**1.8
 flutter=.58+.24*np.sin(2*np.pi*6*t)+.18*np.sin(2*np.pi*11.3*t)
 sound=(low-slow)*envelope*flutter*gain
 start=int(at*rate);audio[start:start+size,0]+=sound*(1-pan);audio[start:start+size,1]+=sound*(1+pan)
audio*=10**(-20/20)/np.max(np.abs(audio))
samples=np.round(audio*32767).astype('<i2')
with wave.open(str(root/'sound-draft-v1.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(rate);w.writeframes(samples.tobytes())
report={'durationSeconds':duration,'sampleRate':rate,'channels':2,'source':'Original synthesized cloth rustles; no recorded speech, music, environmental recordings or external samples.','peakDbFS':float(20*np.log10(np.max(np.abs(audio)))),'rmsDbFS':float(20*np.log10(np.sqrt(np.mean(audio**2)))),'clippedSamples':int(np.sum(np.abs(audio)>=1)),'events':[{'start':a,'duration':b,'relativeGain':c,'pan':d} for a,b,c,d in events]}
(root/'sound-review-v1.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
