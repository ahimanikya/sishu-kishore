import {ease} from './motion-v2.mjs';
const blinks={chaiti:[5.7,11.4,17.2,24.9,30.6,39.7,44.8,50.6],nilu:[6.9,13.3,22.7,29.2,37.6,43.8,49.8]};
export function faceState(t,who){return {blink:blinks[who].some(start=>t>=start&&t<start+4/24),smile:ease((t-(who==='chaiti'?44:51.7))/.25)};}
export function drawExpression(ctx,img,who,kind,at,angle,alpha=1){
 const c=who==='chaiti',blink=kind==='blink';
 const rect=c?(blink?[120,20,630,490]:[760,20,630,490]):(blink?[180,512,560,500]:[820,512,560,500]);
 const anchor=c?(blink?[440,489]:[1080,489]):(blink?[490,980]:[1129,980]);
 ctx.save();ctx.globalAlpha*=alpha;ctx.translate(...at);ctx.rotate(angle);ctx.scale(c?.378:.375,c?.40:.385);
 ctx.drawImage(img,...rect,rect[0]-anchor[0],rect[1]-anchor[1],rect[2],rect[3]);ctx.restore();
}
